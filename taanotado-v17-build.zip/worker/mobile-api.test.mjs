import { describe, it, expect, vi } from "vitest";
import { handleMobileRequest, VoiceQuota } from "./mobile-api.mjs";
const token = "a-private-test-access-code-with-32-characters";
const env = { VOICE_ACCESS_TOKEN: token, OPENAI_API_KEY: "server-key",
  VOICE_TEST_EXPIRES_AT: "2099-01-01T00:00:00Z",
  VOICE_QUOTA: { idFromName: () => "quota", get: () => ({ fetch: async () => new Response(null, { status: 200 }) }) } };
const request = (path, options = {}) => new Request(`https://voice.test/api/voice/${path}`, {
  ...options, headers: { origin: "https://localhost", authorization: `Bearer ${token}`, ...options.headers },
});
describe("serviço de áudio independente", () => {
  it("autoriza preflight Android sem enviar a chave ao aplicativo", async () => {
    const result = await handleMobileRequest(request("process", { method: "OPTIONS" }), env);
    expect(result.status).toBe(204);
    expect(result.headers.get("access-control-allow-origin")).toBe("https://localhost");
    expect(result.headers.get("access-control-allow-credentials")).toBeNull();
  });
  it("recusa código errado e não aceita identidade inventada", async () => {
    const upstream = vi.fn();
    const result = await handleMobileRequest(request("health", { headers: { authorization: "Bearer wrong", "oai-authenticated-user-id": "fake" } }), env, upstream);
    expect(result.status).toBe(401); expect(upstream).not.toHaveBeenCalled();
  });
  it("recusa outra origem, prazo vencido e configuração incompleta", async () => {
    expect((await handleMobileRequest(request("health", { headers: { origin: "https://evil.test" } }), env)).status).toBe(403);
    expect((await handleMobileRequest(request("health"), { ...env, VOICE_TEST_EXPIRES_AT: "2020-01-01" })).status).toBe(403);
    expect((await handleMobileRequest(request("health"), { ...env, VOICE_TEST_EXPIRES_AT: "" })).status).toBe(503);
  });
  it("verifica modelos com segredo no servidor e não faz transcrição no diagnóstico", async () => {
    const upstream = vi.fn(async () => Response.json({ id: "model" }));
    const result = await handleMobileRequest(request("health"), env, upstream);
    expect(result.status).toBe(200);
    expect(upstream.mock.calls.map(([url]) => url)).toEqual([
      "https://api.openai.com/v1/models/gpt-transcribe", "https://api.openai.com/v1/models/gpt-5.6-terra",
    ]);
    expect(await result.text()).not.toContain("server-key");
  });
  it("acesso negado ao modelo produz erro explícito", async () => {
    const result = await handleMobileRequest(request("health"), env, async () => new Response(null, { status: 401 }));
    expect((await result.json()).error).toBe("MODEL_ACCESS_FAILED");
  });
  it("limite diário impede chamada paga", async () => {
    const upstream = vi.fn();
    const result = await handleMobileRequest(request("process", { method: "POST" }), {
      ...env, VOICE_QUOTA: { idFromName: () => "quota", get: () => ({ fetch: async () => new Response(null, { status: 429 }) }) },
    }, upstream);
    expect(result.status).toBe(429); expect(upstream).not.toHaveBeenCalled();
  });
  it("processa bytes Android sem cookies ou login ChatGPT e permite revisão", async () => {
    const form = new FormData();
    form.append("audio", new File([new Uint8Array(2048).fill(7)], "voz.webm", { type: "audio/webm" }));
    form.append("durationSeconds", "4"); form.append("revision", "true");
    const upstream = vi.fn(async (_, options) => {
      if (options.body instanceof FormData) {
        expect(new Uint8Array(await options.body.get("file").arrayBuffer())[0]).toBe(7);
        expect(options.body.get("model")).toBe("gpt-transcribe");
        return Response.json({ text: "O valor correto é trezentos reais" });
      }
      const body = JSON.parse(options.body);
      expect(body.model).toBe("gpt-5.6-terra");
      expect(JSON.parse(body.input[2].content).contexto.revision).toBe(true);
      const keys = Object.keys(body.text.format.schema.properties.fields.properties);
      const fields = Object.fromEntries(keys.map(k => [k, { value: null, evidence: null }]));
      fields.total = { value: 300, evidence: "trezentos reais" };
      return Response.json({ output: [{ content: [{ type: "output_text", text: JSON.stringify({ intent: "service", fields, missing: [], warnings: [] }) }] }] });
    });
    const result = await handleMobileRequest(request("process", { method: "POST", body: form }), env, upstream);
    expect(result.status).toBe(200);
    const data = await result.json();
    expect(data.transcript).toBe("O valor correto é trezentos reais");
    expect(data.interpretation.fields.total.value).toBe(300);
    expect(data.audioSha256).toMatch(/^[a-f0-9]{64}$/);
  });
  it("contador persiste reservas e reinicia após mudar o dia", async () => {
    const data = new Map();
    const storage = { get: async k => data.get(k), put: async (k,v) => data.set(k,v) };
    const quota = new VoiceQuota({ storage: { transaction: async f => f(storage) } }, { VOICE_DAILY_LIMIT: "2" });
    const reserve = () => quota.fetch(new Request("https://quota/reserve", { method: "POST" }));
    expect((await reserve()).status).toBe(200); expect((await reserve()).status).toBe(200);
    expect((await reserve()).status).toBe(429);
    data.set("usage", { day: "2000-01-01", count: 99 });
    expect((await reserve()).status).toBe(200);
  });
});
