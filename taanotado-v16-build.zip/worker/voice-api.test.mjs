import { describe, expect, it, vi } from "vitest";
import { EXTRACTION_SCHEMA, handleVoiceRequest, validateExtraction } from "./voice-api.mjs";

function request(bytes, duration = 4) {
  const form = new FormData();
  form.append("audio", new File([bytes], "gravacao.webm", { type: "audio/webm" }));
  form.append("durationSeconds", String(duration));
  return new Request("https://example.test/api/voice/process", { method: "POST", body: form,
    headers: { origin: "https://example.test", "oai-authenticated-user-id": "usuario" } });
}
function extraction(transcript) {
  const fields = Object.fromEntries(Object.keys(EXTRACTION_SCHEMA.properties.fields.properties)
    .map((key) => [key, { value: null, evidence: null }]));
  if (transcript.includes("João")) {
    fields.client = { value: "João", evidence: "João" };
    fields.received = { value: 300, evidence: "300 reais" };
  } else fields.service = { value: "pintura", evidence: "pintura" };
  return { intent: "payment", fields, missing: [], warnings: [] };
}
describe("áudio gravado até transcrição e IA", () => {
  it("envia bytes reais diferentes e recebe respostas diferentes", async () => {
    const sent = [];
    const upstream = vi.fn(async (url, options) => {
      if (url.endsWith("/audio/transcriptions")) {
        const file = options.body.get("file");
        const bytes = new Uint8Array(await file.arrayBuffer());
        sent.push(bytes);
        return Response.json({ text: bytes[0] === 1 ? "Recebi 300 reais de João hoje" : "Fiz pintura hoje" });
      }
      const transcript = JSON.parse(options.body).input[1].content;
      return Response.json({ output: [{ content: [{ type: "output_text", text: JSON.stringify(extraction(transcript)) }] }] });
    });
    const first = new Uint8Array(2048).fill(1), second = new Uint8Array(2048).fill(2);
    const a = await (await handleVoiceRequest(request(first), { OPENAI_API_KEY: "test-key" }, upstream)).json();
    const b = await (await handleVoiceRequest(request(second), { OPENAI_API_KEY: "test-key" }, upstream)).json();
    expect(sent).toHaveLength(2);
    expect(sent[0]).toEqual(first);
    expect(sent[1]).toEqual(second);
    expect(a.transcript).toBe("Recebi 300 reais de João hoje");
    expect(b.transcript).toBe("Fiz pintura hoje");
    expect(a.transcript).not.toMatch(/Carlos|450|90 de material|2 metros de cabo/);
    expect(a.interpretation.fields.client.value).toBe("João");
    expect(b.interpretation.fields.client.value).toBeNull();
    expect(a.audioSha256).not.toBe(b.audioSha256);
  });
  it("recusa áudio vazio antes de chamar o serviço", async () => {
    const upstream = vi.fn();
    const response = await handleVoiceRequest(request(new Uint8Array(0)), { OPENAI_API_KEY: "test" }, upstream);
    expect(response.status).toBe(422);
    expect((await response.json()).transcript).toBeUndefined();
    expect(upstream).not.toHaveBeenCalled();
  });
  it("falha da transcrição produz erro explícito sem texto alternativo", async () => {
    const response = await handleVoiceRequest(request(new Uint8Array(2048)),
      { OPENAI_API_KEY: "test" }, async () => new Response("falha", { status: 503 }));
    expect(response.status).toBe(502);
    const body = await response.json();
    expect(body.error).toBe("TRANSCRIPTION_FAILED");
    expect(body.transcript).toBeUndefined();
  });
  it("fala incompreensível não aciona IA", async () => {
    const upstream = vi.fn(async () => Response.json({ text: " " }));
    const response = await handleVoiceRequest(request(new Uint8Array(2048)), { OPENAI_API_KEY: "test" }, upstream);
    expect((await response.json()).error).toBe("NO_SPEECH");
    expect(upstream).toHaveBeenCalledTimes(1);
  });
  it("falha da IA preserva apenas a transcrição vinda do áudio", async () => {
    const upstream = vi.fn(async (url) => url.endsWith("/audio/transcriptions")
      ? Response.json({ text: "Recebi 300 reais de João hoje" }) : new Response("falha", { status: 503 }));
    const response = await handleVoiceRequest(request(new Uint8Array(2048)), { OPENAI_API_KEY: "test" }, upstream);
    expect(await response.json()).toMatchObject({ error: "AI_FAILED", transcript: "Recebi 300 reais de João hoje" });
  });
  it("ausência de chave impede chamada externa", async () => {
    const upstream = vi.fn();
    const response = await handleVoiceRequest(request(new Uint8Array(2048)), {}, upstream);
    expect((await response.json()).error).toBe("AI_NOT_CONFIGURED");
    expect(upstream).not.toHaveBeenCalled();
  });
  it("descarta campo cujo valor não é sustentado pela evidência", () => {
    const proposed = extraction("Recebi 300 reais de João hoje");
    proposed.fields.client = { value: "Carlos", evidence: "João" };
    expect(validateExtraction(proposed, "Recebi 300 reais de João hoje").fields.client.value).toBeNull();
  });
});

describe("valores falados por extenso", () => {
  it.each([["trezentos reais", 300], ["mil e duzentos reais", 1200], ["vinte e cinco reais", 25]])("valida %s sem perder a evidência", (evidence, amount) => {
    const raw = extraction("João");
    raw.fields.received = { value: amount, evidence };
    expect(validateExtraction(raw, `Recebi ${evidence} de João`).fields.received.value).toBe(amount);
    raw.fields.received.value = amount + 10;
    expect(validateExtraction(raw, `Recebi ${evidence} de João`).fields.received.value).toBeNull();
  });
});
