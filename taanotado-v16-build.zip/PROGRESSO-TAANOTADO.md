# TáAnotado — versão de trabalho

Continuação do Site existente `falatrampo-demo-wellington`. Esta alteração foi salva sem publicar; o endereço público continua na versão anteriormente publicada.

## Cadeia de áudio

- `src/main.tsx`: `MediaRecorder` obtém o Blob real do microfone, calcula duração útil e SHA-256, guarda uma cópia na caixa local IndexedDB e envia o próprio Blob em `FormData` para `/api/voice/process`. O texto de voz exibido vem da resposta do servidor, nunca de reconhecimento temporário ou exemplo.
- `worker/voice-api.mjs`: valida usuário, origem, MIME, tamanho (1 KiB a 12 MiB) e duração (1 a 120 s). Encaminha o conteúdo original do arquivo para `https://api.openai.com/v1/audio/transcriptions`, modelo `gpt-4o-mini-transcribe`, e recebe `text` da resposta JSON. Transcrição vazia ou erro gera aviso explícito sem texto alternativo.
- O mesmo Worker envia a transcrição recebida à API Responses, modelo `gpt-4o-mini`, com esquema JSON estrito e sem armazenamento (`store: false`). Confere cada campo com um trecho de evidência presente na transcrição e anula valores sem apoio. A resposta contém transcrição, campos estruturados e hash do áudio.
- `src/voice/aiResult.ts`: adapta a interpretação ao fluxo existente de confirmação. Comandos sem dados suficientes pedem esclarecimento; somente a confirmação explícita do usuário salva informações. O áudio continua no estado da página e, quando possível, em IndexedDB para nova tentativa após falha.
- `scripts/build-worker.mjs`: incorpora os arquivos estáticos existentes no Worker que também atende a rota privada da API. Nenhum segredo está no frontend. Configure `OPENAI_API_KEY` como segredo/variável de ambiente do Site existente antes de usar a integração.

## Validação e limites

Testes automatizados usam substitutos das duas APIs externas para conferir o conteúdo binário enviado, duas gravações distintas, recusa de áudio vazio/incompreensível, falha de transcrição, falha de IA, ausência de chave e evidência inconsistente. Esses testes não comprovam precisão de reconhecimento com voz real. Sem `OPENAI_API_KEY`, a rota retorna erro explícito `AI_NOT_CONFIGURED`; ainda é necessário testar fala real em um dispositivo após configurar o segredo e, somente com autorização, publicar.

Os dados do aplicativo seguem locais no navegador. As demais partes do produto não foram alteradas nesta etapa.
