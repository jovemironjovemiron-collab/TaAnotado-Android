export type Status =
  | "orçamento"
  | "aprovado"
  | "agendado"
  | "em andamento"
  | "concluído"
  | "aguardando pagamento"
  | "pago"
  | "cancelado";
export interface Client {
  id: string;
  name: string;
  phone?: string;
  address?: string;
  notes?: string;
  archived?: boolean;
}
export interface Job {
  id: string;
  clientId?: string;
  clientName: string;
  description: string;
  category: string;
  date: string;
  time?: string;
  total: number;
  received: number;
  pending: number;
  expenses: number;
  materials: string[];
  notes: string;
  status: Status;
  nextVisit?: string | null;
  createdAt: string;
}
export interface Draft {
  paymentMethod?: string;
  category?: string;
  phone?: string;
  address?: string;
  client: string | null;
  service: string | null;
  total: number | null;
  received: number | null;
  pending: number | null;
  expenses: number[];
  date: string | null;
  nextVisit: string | null;
  nextVisitTime?: string | null;
  status: Status | null;
  materials: string[];
  notes: string;
  confidence: Record<string, "alta" | "média" | "baixa">;
  warnings: string[];
}
export interface Transaction {
  id: string;
  type: "receita" | "despesa";
  description: string;
  value: number;
  date: string;
  jobId?: string;
  paymentMethod?: string | null;
}
export interface Appointment {
  id: string;
  clientId: string;
  clientName: string;
  date: string;
  time: string;
  description: string;
  createdAt: string;
}
export interface AuditEvent {
  id: string;
  createdAt: string;
  source: "audio" | "texto";
  transcript: string;
  action: "serviço" | "pagamento" | "despesa" | "compromisso";
  recordId: string;
}
export interface UserPrefs {
  profession: string;
  name: string;
  plan: "FREE" | "PREMIUM";
  onboarded: boolean;
}
export interface Usage {
  month: string;
  recordings: number;
  minutes: number;
  aiCalls: number;
  budgets: number;
  receipts: number;
}
