import type { Draft } from "../types";
import type { AIExtraction } from "./aiResult";
export function reviseDraft(current: Draft, correction: AIExtraction, transcript: string): Draft {
  const next = { ...current, expenses: [...current.expenses], materials: [...current.materials] };
  let changes = 0;
  const f = correction.fields;
  for (const [source, target] of [["client", "client"], ["service", "service"], ["phone", "phone"], ["address", "address"], ["paymentMethod", "paymentMethod"], ["date", "nextVisit"], ["time", "nextVisitTime"]] as const) {
    const value = f[source]?.value;
    if (typeof value === "string" && value.trim()) { next[target] = value.trim(); changes++; }
  }
  for (const key of ["total", "received", "pending"] as const) {
    const value = f[key]?.value;
    if (typeof value === "number" && Number.isFinite(value) && value >= 0) { next[key] = value; changes++; }
  }
  if (typeof f.expense?.value === "number") { next.expenses = [f.expense.value]; changes++; }
  if (typeof f.material?.value === "string") { next.materials = [f.material.value]; changes++; }
  if (typeof f.observation?.value === "string") changes++;
  if (!changes) throw new Error("Não identifiquei uma alteração clara. Diga o campo e o novo valor, ou edite diretamente na tela.");
  const total = next.total ?? 0, received = next.received ?? 0;
  if (received > total) throw new Error("A alteração deixa o recebido maior que o total. Confira os dois valores.");
  if (f.pending?.value == null) next.pending = total - received;
  if (Math.abs(total - received - (next.pending ?? 0)) > .01) throw new Error("Total, recebido e saldo não fecham. A versão anterior foi preservada.");
  if (next.nextVisit && !/^\d{4}-\d{2}-\d{2}$/.test(next.nextVisit)) throw new Error("Diga a data completa do retorno ou ajuste o campo na tela.");
  if (next.nextVisitTime && !/^\d{2}:\d{2}$/.test(next.nextVisitTime)) throw new Error("Diga o horário do retorno com clareza.");
  next.notes = [current.notes, `Ajuste por áudio: ${transcript.trim()}`].filter(Boolean).join("\n");
  next.warnings = correction.warnings;
  return next;
}

import type { PreparedCommand } from "./command";
import type { Store } from "../lib";
export function reviseCommand(current: PreparedCommand, correction: AIExtraction, transcript: string, store: Store): PreparedCommand {
  const result = { ...current.result, originalTranscript: `${current.result.originalTranscript}\nAjuste: ${transcript}` };
  const value = (name: string) => correction.fields[name]?.value;
  if (current.kind === "expense") {
    const amount = value("expense");
    if (typeof amount !== "number" || amount <= 0) throw new Error("Diga o novo valor da despesa.");
    return { ...current, result, amount };
  }
  if (current.kind === "payment") {
    const amount = typeof value("received") === "number" ? value("received") as number : current.amount;
    const name = value("client");
    let jobIds = current.jobIds;
    if (typeof name === "string") {
      const clients = store.clients.filter((client) => client.name.localeCompare(name, "pt-BR", { sensitivity: "base" }) === 0);
      if (clients.length !== 1) throw new Error("Identifique um único cliente cadastrado.");
      jobIds = store.jobs.filter((job) => job.clientId === clients[0].id && job.pending > 0).map((job) => job.id);
    }
    if (amount <= 0 || !jobIds.some((jobId) => (store.jobs.find((job) => job.id === jobId)?.pending || 0) >= amount)) throw new Error("Confira o valor e a pendência do pagamento.");
    if (value("received") == null && name == null) throw new Error("Diga o novo valor ou cliente do pagamento.");
    return { ...current, result, amount, jobIds };
  }
  if (current.kind === "appointment") {
    const date = typeof value("date") === "string" ? value("date") as string : current.date;
    const time = typeof value("time") === "string" ? value("time") as string : current.time;
    if (value("date") == null && value("time") == null) throw new Error("Diga a nova data ou horário do compromisso.");
    if (!/^\d{4}-\d{2}-\d{2}$/.test(date) || !/^\d{2}:\d{2}$/.test(time)) throw new Error("Confira a data e o horário.");
    return { ...current, result, date, time };
  }
  throw new Error("Para reorganizar este relato, volte e grave novamente com os detalhes que faltam.");
}
