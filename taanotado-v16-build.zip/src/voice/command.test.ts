import { describe, expect, it } from "vitest";
import { emptyStore } from "../lib";
import { prepareCommand } from "./command";

const store = {
  ...emptyStore,
  clients: [{ id: "joao", name: "João" }],
  jobs: [{ id: "job", clientId: "joao", clientName: "João", description: "Instalação",
    category: "", date: "2026-09-24", total: 500, received: 300, pending: 200,
    expenses: 0, materials: [], notes: "", status: "aguardando pagamento" as const,
    createdAt: "2026-09-24T12:00:00Z" }],
};
describe("comandos seguros", () => {
  it("nunca interpreta silêncio", () => {
    expect(() => prepareCommand(" ", store)).toThrow("Não foi possível compreender");
  });
  it("associa pagamento a uma pendência existente sem criar serviço", () => {
    const command = prepareCommand("João me pagou 200 reais hoje", store);
    expect(command.kind).toBe("payment");
    if (command.kind === "payment") expect(command.jobIds).toEqual(["job"]);
  });
  it("bloqueia pagamento para cliente não identificado", () => {
    expect(prepareCommand("Recebi 200 reais hoje", store).kind).toBe("clarify");
  });
  it("consulta registros sem ação financeira", () => {
    const command = prepareCommand("Quanto ainda tenho para receber?", store);
    expect(command.kind).toBe("query");
    if (command.kind === "query") expect(command.answer).toContain("R$ 200,00");
  });
  it("não atribui a dívida de João a Maria", () => {
    expect(prepareCommand("Quanto Maria ainda deve?", store).kind).toBe("clarify");
  });
  it("consulta Pix apenas nas movimentações marcadas como Pix", () => {
    const withPayments = { ...store, transactions: [
      { id: "a", type: "receita" as const, description: "Pix", value: 80, date: "2026-09-24", paymentMethod: "Pix" },
      { id: "b", type: "receita" as const, description: "Dinheiro", value: 20, date: "2026-09-24", paymentMethod: "Dinheiro" },
    ] };
    const command = prepareCommand("Quanto recebi no Pix?", withPayments);
    expect(command.kind).toBe("query");
    if (command.kind === "query") expect(command.answer).toContain("80,00");
  });
  it("não cria serviço a partir de correção isolada", () => {
    expect(prepareCommand("Não foi 500, foi 550", store).kind).toBe("clarify");
  });
  it("separa despesa avulsa de serviço", () => {
    const command = prepareCommand("Gastei 87,50 de material", store);
    expect(command.kind).toBe("expense");
    if (command.kind === "expense") expect(command.amount).toBe(87.5);
  });
  it("não inventa descrição do serviço nem valor ausente", () => {
    expect(prepareCommand("Fiz um serviço para João hoje", store).kind).toBe("clarify");
  });
  it("não escolhe uma entre duas pendências sem confirmação", () => {
    const two = { ...store, jobs: [...store.jobs, { ...store.jobs[0], id: "outro" }] };
    const command = prepareCommand("João me pagou 100", two);
    expect(command.kind).toBe("payment");
    if (command.kind === "payment") expect(command.jobIds).toEqual(["job", "outro"]);
  });
  it("prepara retorno com cliente e horário explícito sem criar serviço", () => {
    const command = prepareCommand("Volto na casa de João sexta às duas da tarde", store);
    expect(command.kind).toBe("appointment");
    if (command.kind === "appointment") expect(command.time).toBe("14:00");
  });
  it("pede esclarecimento quando o período do horário é ambíguo", () => {
    expect(prepareCommand("Volto na casa de João sexta às duas", store).kind).toBe("clarify");
  });
});
