import type {
  LanguageUnderstandingProvider,
  SpeechToTextProvider,
  StructuredDataValidator,
  ActionPlanner,
  VoiceContext,
  StructuredVoiceResult,
} from "./contracts";
export type PipelineStage =
  | "received"
  | "transcribing"
  | "normalizing"
  | "interpreting"
  | "validating"
  | "awaiting_confirmation"
  | "ready"
  | "error";
export class VoicePipeline {
  constructor(
    private stt: SpeechToTextProvider,
    private nlu: LanguageUnderstandingProvider,
    private validator: StructuredDataValidator,
    private planner: ActionPlanner,
  ) {}
  async process(
    audio: Blob,
    context: VoiceContext = {},
    onStage?: (s: PipelineStage) => void,
  ): Promise<StructuredVoiceResult> {
    try {
      onStage?.("transcribing");
      const tr = await this.stt.transcribe(audio, { language: "pt-BR" });
      if (!tr.original?.trim()) throw new Error("Não foi possível transcrever o áudio.");
      onStage?.("interpreting");
      const result = await this.nlu.understand(tr.original, context);
      onStage?.("validating");
      const check = this.validator.validate(result);
      result.warnings = [...new Set([...result.warnings, ...check.warnings])];
      result.conflicts = check.conflicts;
      result.suggestedActions = this.planner.plan(result, context);
      onStage?.("awaiting_confirmation");
      return result;
    } catch (e) {
      onStage?.("error");
      throw e;
    }
  }
}
