import type {
  ActionPlanner,
  ProposedAction,
  StructuredVoiceResult,
  VoiceContext,
} from "./contracts";
export class SafeActionPlanner implements ActionPlanner {
  plan(r: StructuredVoiceResult, context?: VoiceContext): ProposedAction[] {
    const a: ProposedAction[] = [];
    if (r.intent === "correction")
      a.push({
        type: "correct_recent_candidate",
        payload: { transcript: r.normalizedTranscript },
        requiresConfirmation: true,
        reason: "Correção por voz nunca sobrescreve silenciosamente",
      });
    if (r.client.value)
      a.push({
        type: "upsert_client_candidate",
        payload: { name: r.client.value },
        requiresConfirmation: true,
        reason: "Cliente identificado na fala",
      });
    const isPaymentOnly =
      r.intent === "payment" && !r.service.value && r.financial.total.value == null;
    if (isPaymentOnly)
      a.push({
        type: "match_open_receivable_candidate",
        payload: {
          clientName: r.client.value,
          paymentValue: r.financial.received.value,
          pendingValue: r.financial.pending.value,
          expectedPaymentDate: r.financial.expectedPaymentDate,
          lastServiceId: context?.lastServiceId,
        },
        requiresConfirmation: true,
        reason: "Pagamento deve ser associado a uma pendência existente",
      });
    if (
      r.service.value ||
      (r.financial.total.value != null && r.intent !== "payment")
    )
      a.push({
        type: "upsert_service_candidate",
        payload: {
          description: r.service.value,
          total: r.financial.total.value,
        },
        requiresConfirmation: true,
        reason: "Serviço identificado",
      });
    for (const x of r.expenses)
      a.push({
        type: "add_expense_candidate",
        payload: { ...x },
        requiresConfirmation: true,
        reason: "Despesa financeira",
      });
    for (const x of r.payments)
      a.push({
        type: "add_payment_candidate",
        payload: { ...x },
        requiresConfirmation: true,
        reason: "Pagamento financeiro",
      });
    for (const x of r.materials)
      a.push({
        type: "add_material_candidate",
        payload: { ...x },
        requiresConfirmation: true,
        reason: "Material mencionado",
      });
    for (const x of r.tasks)
      a.push({
        type: "add_task_candidate",
        payload: { ...x },
        requiresConfirmation: true,
        reason: "Tarefa mencionada",
      });
    for (const x of r.schedule)
      a.push({
        type: "add_appointment_candidate",
        payload: { ...x },
        requiresConfirmation: true,
        reason: "Compromisso mencionado",
      });
    if (r.intent === "undo")
      a.push({
        type: "request_undo",
        payload: { scope: "last_voice_action" },
        requiresConfirmation: true,
        reason: "Ação destrutiva sempre exige confirmação",
      });
    return a;
  }
}
