import { describe, expect, it } from "vitest";
import { reviseDraft } from "./revision";
import { organizeReport, type WorkReport } from "../report";
const report = { client: "João", service: "Pintura", profession: "Pintor", total: "450", received: "100", expense: "90", materials: "Tinta", date: "2026-10-04", notes: "Sala", status: "em andamento", phone: "", address: "", email: "", reference: "", paymentMethod: "", paymentDue: "", deadline: "", startTime: "", endTime: "", tasks: "", warranty: "", budgetValidity: "", nextVisit: "", nextVisitTime: "" } as WorkReport;
describe("ajuste por áudio", () => {
  it("muda apenas o campo citado e recalcula o saldo sem alterar o original", () => {
    const original = organizeReport(report);
    const revised = reviseDraft(original, { intent: "service", fields: { total: { value: 500, evidence: "500" } }, missing: [], warnings: [] }, "O total é 500");
    expect(revised.total).toBe(500);
    expect(revised.pending).toBe(400);
    expect(revised.client).toBe("João");
    expect(revised.materials).toEqual(["Tinta"]);
    expect(original.total).toBe(450);
    expect(revised.notes).toContain("O total é 500");
  });
  it("recusa correção ambígua ou valores incompatíveis preservando dados", () => {
    const original = organizeReport(report);
    expect(() => reviseDraft(original, { intent: "clarify", fields: {}, missing: [], warnings: [] }, "Não gostei")).toThrow("alteração clara");
    expect(() => reviseDraft(original, { intent: "service", fields: { received: { value: 600, evidence: "600" } }, missing: [], warnings: [] }, "Recebi 600")).toThrow("maior");
    expect(original.received).toBe(100);
  });
});
