import type { Draft } from "../types";
import type { Store } from "../lib";
import { isoToday } from "../lib";
import type { StructuredVoiceResult } from "./contracts";
import type { PreparedCommand } from "./command";
import { prepareCommand } from "./command";

type Field = { value: string | number | null; evidence: string | null };
export interface AIExtraction {
  intent: "service" | "payment" | "expense" | "appointment" | "query" | "clarify";
  fields: Record<string, Field>;
  missing: string[];
  warnings: string[];
}
const string = (field?: Field) => typeof field?.value === "string" ? field.value.trim() : null;
const number = (field?: Field) => typeof field?.value === "number" && Number.isFinite(field.value)
  ? field.value : null;
const same = (a: string, b: string) => a.localeCompare(b, "pt-BR", { sensitivity: "base" }) === 0;

export function prepareAIResult(transcript: string, ai: AIExtraction, store: Store):
  { command: PreparedCommand; draft: Draft | null } {
  const f = ai.fields;
  const client = string(f.client), service = string(f.service), total = number(f.total),
    received = number(f.received), pending = number(f.pending), expense = number(f.expense),
    date = string(f.date), time = string(f.time), material = string(f.material);
  const result: StructuredVoiceResult = {
    schemaVersion: 1, intent: ai.intent === "service" ? "new_service" : ai.intent === "appointment" ? "schedule"
      : ai.intent === "clarify" ? "unknown" : ai.intent,
    originalTranscript: transcript, normalizedTranscript: transcript, confidence: 0,
    client: { value: client, confidence: client ? "high" : "missing", evidence: f.client?.evidence || undefined },
    service: { value: service, confidence: service ? "high" : "missing", evidence: f.service?.evidence || undefined },
    financial: {
      total: { value: total, confidence: total != null ? "high" : "missing", evidence: f.total?.evidence || undefined },
      received: { value: received, confidence: received != null ? "high" : "missing", evidence: f.received?.evidence || undefined },
      pending: { value: pending, confidence: pending != null ? "high" : "missing", evidence: f.pending?.evidence || undefined },
      estimatedProfit: total != null ? total - (expense || 0) : null,
    },
    expenses: expense != null ? [{ value: expense, category: "outros", evidence: f.expense?.evidence || "" }] : [],
    payments: received != null ? [{ value: received, method: string(f.paymentMethod), evidence: f.received?.evidence || "" }] : [],
    materials: material ? [{ description: material, quantity: number(f.quantity), unit: null, purchased: false }] : [],
    tasks: [], schedule: date ? [{ date, time, period: null, description: string(f.commitment) || "" }] : [],
    notes: transcript ? [transcript] : [], warnings: ai.warnings, missingInformation: ai.missing,
    conflicts: [], suggestedActions: [], fingerprint: "",
  };
  const clarify = (reason: string): { command: PreparedCommand; draft: null } =>
    ({ command: { kind: "clarify", result, reason }, draft: null });
  if (ai.intent === "query") {
    const query = prepareCommand(transcript, store);
    return { command: query.kind === "query" ? { ...query, result } : { kind: "clarify", result,
      reason: "Não encontrei dados suficientes para responder com segurança." }, draft: null };
  }
  if (ai.intent === "service") {
    if (!client || !service || total == null) return clarify("Informe cliente, serviço e valor total antes de salvar.");
    if (received != null && received > total) return clarify("O recebido supera o valor total. Confira os valores.");
    if (pending != null && received != null && Math.abs(total - received - pending) > .01)
      return clarify("Os valores não fecham. Corrija antes de salvar.");
    const draft: Draft = { client, service, total, received, pending, expenses: expense != null ? [expense] : [],
      date: isoToday(), nextVisit: date && /^\d{4}-\d{2}-\d{2}$/.test(date) ? date : null,
      nextVisitTime: time && /^\d{2}:\d{2}$/.test(time) ? time : null,
      status: null, materials: material ? [material] : [], notes: transcript,
      confidence: { cliente: "alta", valores: "alta", data: date ? "média" : "baixa" },
      warnings: ai.warnings };
    return { command: { kind: "service", result }, draft };
  }
  if (ai.intent === "payment") {
    if (!client || received == null || received <= 0) return clarify("Identifique cliente e valor recebido.");
    const clients = store.clients.filter((c) => same(c.name, client));
    if (clients.length !== 1) return clarify("Identifique um único cliente cadastrado.");
    const jobIds = store.jobs.filter((j) => j.clientId === clients[0].id && j.pending > 0).map((j) => j.id);
    return jobIds.length ? { command: { kind: "payment", result, amount: received, jobIds }, draft: null }
      : clarify("Não encontrei pendência registrada para esse cliente.");
  }
  if (ai.intent === "expense") return expense != null && expense > 0
    ? { command: { kind: "expense", result, amount: expense }, draft: null }
    : clarify("Informe o valor da despesa.");
  if (ai.intent === "appointment") {
    const clients = store.clients.filter((c) => client && same(c.name, client));
    return clients.length === 1 && date && /^\d{4}-\d{2}-\d{2}$/.test(date) &&
      time && /^\d{2}:\d{2}$/.test(time)
      ? { command: { kind: "appointment", result, clientId: clients[0].id, date, time }, draft: null }
      : clarify("Identifique cliente, data e horário antes de marcar.");
  }
  return clarify("A IA não identificou dados suficientes para uma ação segura.");
}
