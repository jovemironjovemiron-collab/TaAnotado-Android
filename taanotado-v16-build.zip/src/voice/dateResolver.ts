const days: Record<string, number> = {
  domingo: 0,
  segunda: 1,
  terca: 2,
  quarta: 3,
  quinta: 4,
  sexta: 5,
  sabado: 6,
};
const iso = (d: Date) => {
  const x = new Date(d.getTime() - d.getTimezoneOffset() * 60000);
  return x.toISOString().slice(0, 10);
};
export function resolveRelativeDate(
  text: string,
  now = new Date(),
): {
  date: string | null;
  period: string | null;
  time: string | null;
  confidence: "high" | "medium" | "low";
} {
  const t = text;
  const d = new Date(now);
  let found = false;
  if (/\bhoje\b/.test(t)) found = true;
  else if (/\bamanha\b/.test(t)) {
    d.setDate(d.getDate() + 1);
    found = true;
  } else {
    const m = t.match(
      /\b(segunda|terca|quarta|quinta|sexta|sabado|domingo)(?:-feira)?(?: que vem)?\b/,
    );
    if (m) {
      const target = days[m[1]];
      let add = (target - d.getDay() + 7) % 7 || 7;
      d.setDate(d.getDate() + add);
      found = true;
    }
  }
  const hm = t.match(/\b(?:as|às)?\s*(\d{1,2})(?::(\d{2}))?\s*(?:h|horas?)\b/);
  const namedHour = t.match(/\b(?:as|às)\s+(\d{1,2}|uma|duas|tres|quatro|cinco|seis|sete|oito|nove|dez|onze|doze)\s+(?:da|de)\s+(manha|tarde|noite)\b/);
  const namedHours: Record<string, number> = { uma: 1, duas: 2, tres: 3, quatro: 4,
    cinco: 5, seis: 6, sete: 7, oito: 8, nove: 9, dez: 10, onze: 11, doze: 12 };
  const period = /depois do almoco/.test(t)
    ? "depois do almoço"
    : /cedo|pela manha/.test(t)
      ? "manhã"
      : /a tarde/.test(t)
        ? "tarde"
        : /a noite/.test(t)
          ? "noite"
          : null;
  return {
    date: found ? iso(d) : null,
    period,
    time: hm ? `${hm[1].padStart(2, "0")}:${hm[2] || "00"}` : namedHour
      ? `${String(((namedHours[namedHour[1]] ?? Number(namedHour[1])) % 12) + (namedHour[2] === "tarde" || namedHour[2] === "noite" ? 12 : 0)).padStart(2, "0")}:00`
      : null,
    confidence: found ? (hm || namedHour || period ? "high" : "medium") : "low",
  };
}
