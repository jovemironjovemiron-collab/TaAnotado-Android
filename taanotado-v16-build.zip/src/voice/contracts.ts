export type ConfidenceLevel = "high" | "medium" | "low" | "missing";
export type VoiceIntent =
  | "new_service"
  | "payment"
  | "expense"
  | "schedule"
  | "task"
  | "correction"
  | "undo"
  | "query"
  | "mixed"
  | "unknown";

export interface Confident<T> {
  value: T | null;
  confidence: ConfidenceLevel;
  evidence?: string;
}
export interface VoiceExpense {
  value: number;
  category: string;
  evidence: string;
}
export interface VoiceMaterial {
  description: string;
  quantity: number | null;
  unit: string | null;
  purchased: boolean;
  unitPrice?: number | null;
  totalCost?: number | null;
}
export interface VoiceTask {
  description: string;
  dueDate: string | null;
  completed: boolean;
}
export interface VoiceSchedule {
  date: string | null;
  period: string | null;
  time: string | null;
  description: string;
}
export interface VoiceConflict {
  code: string;
  message: string;
  fields: string[];
  expected?: number;
  informed?: number;
}
export interface ProposedAction {
  type: string;
  payload: Record<string, unknown>;
  requiresConfirmation: boolean;
  reason: string;
}

export interface StructuredVoiceResult {
  schemaVersion: 1;
  intent: VoiceIntent;
  originalTranscript: string;
  normalizedTranscript: string;
  client: Confident<string>;
  service: Confident<string>;
  financial: {
    total: Confident<number>;
    received: Confident<number>;
    pending: Confident<number>;
    estimatedProfit: number | null;
    expectedPaymentDate?: string | null;
  };
  expenses: VoiceExpense[];
  payments: Array<{ value: number; method: string | null; evidence: string }>;
  materials: VoiceMaterial[];
  tasks: VoiceTask[];
  schedule: VoiceSchedule[];
  notes: string[];
  confidence: number;
  warnings: string[];
  missingInformation: string[];
  conflicts: VoiceConflict[];
  suggestedActions: ProposedAction[];
  fingerprint: string;
}

export interface TranscriptionResult {
  original: string;
  providerConfidence?: number;
  words?: Array<{ text: string; confidence?: number }>;
}
export interface SpeechToTextProvider {
  transcribe(
    audio: Blob,
    options: { language: "pt-BR"; hints?: string[] },
  ): Promise<TranscriptionResult>;
}
export interface LanguageUnderstandingProvider {
  understand(
    transcript: string,
    context?: VoiceContext,
  ): Promise<StructuredVoiceResult>;
}
export interface StructuredDataValidator {
  validate(result: StructuredVoiceResult): ValidationResult;
}
export interface ActionPlanner {
  plan(result: StructuredVoiceResult, context?: VoiceContext): ProposedAction[];
}
export interface OrganizaeRepository {
  findClientCandidates(
    name: string,
  ): Promise<Array<{ id: string; name: string }>>;
  findOpenServices(
    clientId: string,
  ): Promise<Array<{ id: string; description: string }>>;
  executeConfirmed(actions: ProposedAction[], auditId: string): Promise<void>;
}
export interface VoiceContext {
  now?: Date;
  lastClientId?: string;
  lastClientName?: string;
  lastServiceId?: string;
  knownClients?: Array<{ id: string; name: string }>;
}
export interface ValidationResult {
  valid: boolean;
  warnings: string[];
  conflicts: VoiceConflict[];
  requiresConfirmation: boolean;
}
