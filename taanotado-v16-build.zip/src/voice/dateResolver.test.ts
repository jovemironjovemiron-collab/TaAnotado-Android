import { expect, it } from "vitest";
import { resolveRelativeDate } from "./dateResolver";
import { normalizePortuguese } from "./normalizer";

it("interpreta explicitamente duas da tarde como 14h", () => {
  expect(resolveRelativeDate(normalizePortuguese("Volto sexta às duas da tarde"),
    new Date("2026-09-24T12:00:00-03:00")).time).toBe("14:00");
});
it("não inventa manhã ou tarde para duas sem período", () => {
  expect(resolveRelativeDate(normalizePortuguese("Volto sexta às duas"),
    new Date("2026-09-24T12:00:00-03:00")).time).toBeNull();
});
