import type { Store } from "../lib";
import { interpretPortuguese } from "./interpreter";
import type { StructuredVoiceResult } from "./contracts";

export type PreparedCommand =
  | { kind: "service"; result: StructuredVoiceResult }
  | { kind: "payment"; result: StructuredVoiceResult; jobIds: string[]; amount: number }
  | { kind: "expense"; result: StructuredVoiceResult; amount: number }
  | { kind: "appointment"; result: StructuredVoiceResult; clientId: string; date: string; time: string }
  | { kind: "query"; result: StructuredVoiceResult; answer: string }
  | { kind: "clarify"; result: StructuredVoiceResult; reason: string };

const same = (a: string, b: string) =>
  a.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase().trim() ===
  b.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase().trim();
const brl = (n: number) => new Intl.NumberFormat("pt-BR", { style: "currency", currency: "BRL" }).format(n);

export function prepareCommand(transcript: string, store: Store): PreparedCommand {
  if (!transcript.trim()) throw new Error("Não foi possível compreender o relato.");
  const result = interpretPortuguese(transcript, { knownClients: store.clients });
  const normalized = result.normalizedTranscript;
  if (result.intent === "query") {
    const today = new Date();
    const month = today.toISOString().slice(0, 7);
    if (/quanto.*(?:ganhei|recebi|faturei|gastei|despesa|lucro)/.test(normalized)) {
      const transactions = store.transactions.filter((t) =>
        (!/mes|mês/.test(normalized) || t.date.startsWith(month)) &&
        (!/\bpix\b/.test(normalized) || t.paymentMethod === "Pix"));
      const income = transactions.filter((t) => t.type === "receita").reduce((n, t) => n + t.value, 0);
      const expense = transactions.filter((t) => t.type === "despesa").reduce((n, t) => n + t.value, 0);
      const value = /gast|despesa/.test(normalized) ? expense : /lucro/.test(normalized) ? income - expense : income;
      return { kind: "query", result, answer: `${brl(value)} conforme as movimentações registradas ${/mes|mês/.test(normalized) ? "neste mês" : "neste aparelho"}.` };
    }
    if (/quanto.*(?:receber|devendo|deve)|quem.*devendo/.test(normalized)) {
      const mentioned = store.clients.filter((c) => normalized.includes(c.name.normalize("NFD")
        .replace(/[\u0300-\u036f]/g, "").toLowerCase()));
      if (mentioned.length > 1) return { kind: "clarify", result, reason: "Qual cliente você quer consultar?" };
      if (/quanto\s+[a-z]+\s+(?:ainda\s+)?deve/.test(normalized) && !mentioned.length)
        return { kind: "clarify", result, reason: "Não encontrei esse cliente nos registros deste aparelho." };
      const name = result.client.value || mentioned[0]?.name;
      const jobs = store.jobs.filter((j) => j.pending > 0 && (!name || same(j.clientName, name)));
      const total = jobs.reduce((n, j) => n + j.pending, 0);
      return { kind: "query", result, answer: name && !jobs.length
        ? `Não encontrei pendência registrada para ${name}.`
        : `${jobs.length} serviço(s) com ${brl(total)} a receber, conforme os registros deste aparelho.` };
    }
    return { kind: "clarify", result, reason: "Ainda não consigo responder a esta pergunta com segurança usando seus registros." };
  }
  if (["correction", "undo"].includes(result.intent))
    return { kind: "clarify", result, reason: "Para corrigir ou desfazer um registro, escolha primeiro o registro exato. Nada foi alterado." };
  if (["schedule", "task"].includes(result.intent) ||
    (result.intent === "mixed" && /\b(voltar|retorno|marca|agendar|lembra)\b/.test(normalized) &&
      !/\b(fiz|cobrei|realizei)\b/.test(normalized))) {
    const candidates = store.clients.filter((c) => normalized.includes(c.name.normalize("NFD")
      .replace(/[\u0300-\u036f]/g, "").toLowerCase()));
    const schedule = result.schedule[0];
    if (candidates.length !== 1) return { kind: "clarify", result, reason: "Identifique um cliente cadastrado para este compromisso." };
    if (!schedule?.date || !schedule.time) return { kind: "clarify", result,
      reason: "Informe o dia e o horário com manhã ou tarde para marcar o compromisso." };
    return { kind: "appointment", result, clientId: candidates[0].id, date: schedule.date, time: schedule.time };
  }
  const newService = /\b(fiz|realizei|iniciei|conclui|cobrei|orcamento|orçamento)\b/.test(normalized);
  const payment = result.financial.received.value;
  if (!newService && /\b(recebi|pagou|me deu|quitou|acertou)\b/.test(normalized) && payment != null) {
    if (!result.client.value) return { kind: "clarify", result, reason: "Qual cliente fez o pagamento?" };
    const clients = store.clients.filter((c) => same(c.name, result.client.value!));
    if (clients.length !== 1) return { kind: "clarify", result, reason: clients.length > 1
      ? "Há clientes com o mesmo nome. Identifique qual deles pagou." : "Não encontrei esse cliente cadastrado." };
    const jobs = store.jobs.filter((j) => j.clientId === clients[0].id && j.pending > 0);
    return jobs.length
      ? { kind: "payment", result, amount: payment, jobIds: jobs.map((j) => j.id) }
      : { kind: "clarify", result, reason: "Não encontrei serviço com saldo pendente para esse cliente." };
  }
  const expense = result.expenses.reduce((n, e) => n + e.value, 0);
  if (!newService && result.intent === "expense" && expense > 0)
    return { kind: "expense", result, amount: expense };
  if (newService && result.client.value && result.service.value &&
    !same(result.service.value, "serviço") && result.financial.total.value != null)
    return { kind: "service", result };
  return { kind: "clarify", result, reason: "Faltam dados para criar um serviço com segurança. Informe cliente, tipo de serviço e valor, inclusive zero se for gratuito." };
}
