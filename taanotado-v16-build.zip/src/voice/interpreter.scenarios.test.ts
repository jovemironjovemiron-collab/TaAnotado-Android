import { describe, expect, it } from "vitest";
import { interpretPortuguese } from "./interpreter";
import { normalizePortuguese } from "./normalizer";
import { DeterministicValidator } from "./validator";
import { SafeActionPlanner } from "./actionPlanner";
const now = new Date("2026-09-24T12:00:00-03:00");
type Expected = {
  intent?: string;
  client?: string | null;
  total?: number | null;
  received?: number | null;
  pending?: number | null;
  expense?: number;
  materials?: number;
  schedule?: boolean;
  conflict?: boolean;
  normalized?: string;
  action?: string;
};
const cases: Array<[string, string, Expected]> = [
  [
    "fala curta",
    "Serviço para João por 100 reais",
    { intent: "new_service", client: "Joao", total: 100 },
  ],
  [
    "fala longa",
    "Hoje fiz uma instalação para Carlos por 450 reais. Gastei 90 de material. Ele pagou 200 e ficou devendo 250. Volto sexta-feira para terminar e preciso comprar 2 metros de cabo.",
    {
      intent: "mixed",
      client: "Carlos",
      total: 450,
      received: 200,
      pending: 250,
      expense: 90,
      materials: 1,
      schedule: true,
    },
  ],
  [
    "fala rápida sem pontuação",
    "fiz instalacao para maria por 300 gastei 50 ela pagou 100",
    { intent: "mixed", client: "Maria", total: 300, received: 100 },
  ],
  [
    "pausas transcritas",
    "Fiz... uma instalação para Pedro, por 500.",
    { client: "Pedro", total: 500 },
  ],
  [
    "valor por extenso",
    "Cobrei quatrocentos e cinquenta reais",
    { total: 450, normalized: "450" },
  ],
  [
    "valor em conto",
    "Cobrei 450 conto",
    { total: 450, normalized: "450 reais" },
  ],
  ["valor em reais", "Cobrei 450 reais", { total: 450 }],
  [
    "gasto por extenso",
    "Gastei noventa de material",
    { intent: "expense", expense: 90 },
  ],
  [
    "pagamento ele deu",
    "Ele deu duzentos reais",
    { intent: "payment", received: 200 },
  ],
  ["saldo faltando", "Ficou faltando 250 reais", { pending: 250 }],
  ["sexta eu volto", "Sexta eu volto", { schedule: true }],
  ["sexta que vem", "Volto sexta que vem", { schedule: true }],
  ["amanhã cedo", "Amanhã cedo volto", { schedule: true }],
  ["depois do almoço", "Volto amanhã depois do almoço", { schedule: true }],
  [
    "duas peças",
    "Preciso comprar duas peças de tomada",
    { intent: "task", materials: 1 },
  ],
  ["metros de cabo", "Preciso comprar dois metros de cabo", { materials: 1 }],
  [
    "cliente novo",
    "Fiz pintura para Roberto por 800",
    { client: "Roberto", total: 800 },
  ],
  [
    "cliente com sobrenome",
    "Fiz pintura para Carlos Silva por 800",
    { client: "Carlos Silva", total: 800 },
  ],
  [
    "cliente no início",
    "Carlos me pagou 200 reais",
    { client: "Carlos", received: 200 },
  ],
  [
    "cliente existente pelo contexto",
    "Ele pagou mais 100",
    { client: "Carlos", received: 100 },
  ],
  [
    "pronome sem contexto",
    "Ela pagou mais 100",
    { client: null, received: 100 },
  ],
  [
    "pagamento parcial",
    "Carlos me pagou 200 dos 500",
    { client: "Carlos", received: 200, total: 500, pending: 300 },
  ],
  [
    "pagamento completo",
    "Serviço para Ana por 300 e ela pagou tudo",
    { client: "Ana", total: 300, received: 300, pending: 0 },
  ],
  [
    "pagamento pix",
    "João me pagou 150 no Pix",
    { client: "Joao", received: 150 },
  ],
  [
    "pagamento dinheiro",
    "Maria me pagou 80 em dinheiro",
    { client: "Maria", received: 80 },
  ],
  ["despesa material", "Gastei 80 de material", { expense: 80 }],
  ["despesa combustível", "Despesa de 60 com combustível", { expense: 60 }],
  [
    "múltiplos assuntos",
    "Fiz instalação para Beto por 900, gastei 100 e ele pagou 400. Volto segunda.",
    {
      intent: "mixed",
      client: "Beto",
      total: 900,
      received: 400,
      expense: 100,
      schedule: true,
    },
  ],
  [
    "tarefa comprar",
    "Preciso comprar 3 tomadas amanhã",
    { intent: "mixed", materials: 1, schedule: true },
  ],
  [
    "tarefa finalizar",
    "Volto sexta para finalizar a instalação",
    { schedule: true },
  ],
  [
    "correção",
    "Não foi 90 de material, foi 80",
    { intent: "correction", action: "correct_recent_candidate" },
  ],
  [
    "correção explícita",
    "Corrige o último valor para 70",
    { intent: "correction", action: "correct_recent_candidate" },
  ],
  ["cancelamento", "Cancela isso", { intent: "undo", action: "request_undo" }],
  [
    "apagar último",
    "Apaga o último lançamento",
    { intent: "undo", action: "request_undo" },
  ],
  [
    "desfazer",
    "Desfaz o que eu falei",
    { intent: "undo", action: "request_undo" },
  ],
  ["não salvar", "Não salva isso", { intent: "undo", action: "request_undo" }],
  [
    "valores corretos",
    "Serviço por 450, recebi 200 e ficou devendo 250",
    { total: 450, received: 200, pending: 250, conflict: false },
  ],
  [
    "valores inconsistentes",
    "Serviço por 450, recebi 200 e ficou devendo 300",
    { total: 450, received: 200, pending: 300, conflict: true },
  ],
  [
    "zero pendente",
    "Serviço por 200, recebi 200",
    { total: 200, received: 200, pending: 0 },
  ],
  [
    "sem valor inventado",
    "Fiz uma instalação para Paulo",
    { client: "Paulo", total: null },
  ],
  [
    "sem cliente inventado",
    "Gastei 40 de material",
    { client: null, expense: 40 },
  ],
  ["consulta devedores", "Quem está me devendo", { intent: "query" }],
  ["consulta cliente", "Quanto Carlos ainda deve", { intent: "query" }],
  ["consulta semana", "Quanto ganhei esta semana", { intent: "query" }],
  ["consulta gasto", "Quanto gastei hoje", { intent: "query" }],
  ["consulta amanhã", "Quais serviços tenho amanhã", { intent: "query" }],
  [
    "consulta cobrança",
    "Tenho algum cliente para cobrar hoje",
    { intent: "query" },
  ],
  ["consulta lucro", "Quanto lucrei esse mês", { intent: "query" }],
  ["consulta materiais", "O que preciso comprar amanhã", { intent: "query" }],
  [
    "consulta último serviço",
    "Qual foi meu último serviço para Carlos",
    { intent: "query" },
  ],
  ["horário 14h", "Volto sexta às 14h", { schedule: true }],
  ["horário com minutos", "Volto amanhã às 14:30 horas", { schedule: true }],
  ["quantia decimal", "Cobrei 450,50 reais", { total: 450.5 }],
  ["quantia com milhar", "Cobrei 1.200 reais", { total: 1200 }],
  [
    "cinco itens",
    "Preciso comprar cinco cabos para amanhã",
    { materials: 1, schedule: true },
  ],
  [
    "serviço pintura",
    "Fiz pintura para Lúcia por 1200",
    { client: "Lucia", total: 1200 },
  ],
  [
    "serviço limpeza",
    "Fiz limpeza para Rosa por 180",
    { client: "Rosa", total: 180 },
  ],
  [
    "serviço conserto",
    "Fiz conserto para Davi por 250",
    { client: "Davi", total: 250 },
  ],
  ["fala vazia", "", { intent: "unknown", client: null, total: null }],
  ["transcrição incompleta", "Fiz um serviço para", { total: null }],
  [
    "informações contraditórias",
    "Cobrei 500, recebi 300, faltam 250",
    { conflict: true },
  ],
  [
    "entrada financeira",
    "Serviço por 1000 com entrada de 300",
    { total: 1000, received: 300, pending: 700 },
  ],
  [
    "quitação",
    "Serviço para Rui por 700 e ele quitou",
    { client: "Rui", total: 700, received: 700, pending: 0 },
  ],
];
describe("interpretador pt-BR — cenários reais", () => {
  it("mantém no mínimo 50 cenários", () =>
    expect(cases.length).toBeGreaterThanOrEqual(50));
  it.each(cases)("%s", (_name, input, e) => {
    const r = interpretPortuguese(input, {
      now,
      lastClientName: input.startsWith("Ele pagou") ? "Carlos" : undefined,
    });
    expect(r.originalTranscript).toBe(input);
    expect(r.schemaVersion).toBe(1);
    if (e.intent !== undefined) expect(r.intent).toBe(e.intent);
    if ("client" in e) expect(r.client.value).toBe(e.client);
    if ("total" in e) expect(r.financial.total.value).toBe(e.total);
    if ("received" in e) expect(r.financial.received.value).toBe(e.received);
    if ("pending" in e) expect(r.financial.pending.value).toBe(e.pending);
    if (e.expense !== undefined)
      expect(r.expenses.some((x) => x.value === e.expense)).toBe(true);
    if (e.materials !== undefined) expect(r.materials.length).toBe(e.materials);
    if (e.schedule !== undefined)
      expect(r.schedule.length > 0).toBe(e.schedule);
    if (e.conflict !== undefined)
      expect(r.conflicts.length > 0).toBe(e.conflict);
    if (e.normalized) expect(r.normalizedTranscript).toContain(e.normalized);
    if (e.action)
      expect(r.suggestedActions.some((x) => x.type === e.action)).toBe(true);
  });
  it("gera fingerprint idêntica para áudio duplicado", () => {
    const a = interpretPortuguese("Carlos me pagou 100", {
      now,
      lastServiceId: "s1",
    });
    const b = interpretPortuguese("Carlos me pagou 100", {
      now,
      lastServiceId: "s1",
    });
    expect(a.fingerprint).toBe(b.fingerprint);
  });
  it("muda fingerprint quando muda o serviço", () => {
    const a = interpretPortuguese("Carlos me pagou 100", {
      now,
      lastServiceId: "s1",
    });
    const b = interpretPortuguese("Carlos me pagou 100", {
      now,
      lastServiceId: "s2",
    });
    expect(a.fingerprint).not.toBe(b.fingerprint);
  });
  it("validador sempre exige confirmação humana", () => {
    const r = interpretPortuguese("Serviço por 100, recebi 50");
    expect(new DeterministicValidator().validate(r).requiresConfirmation).toBe(
      true,
    );
  });
  it("planejador apenas propõe ações confirmáveis", () => {
    const r = interpretPortuguese(
      "Fiz instalação para João por 300, gastei 50",
    );
    expect(
      new SafeActionPlanner().plan(r).every((x) => x.requiresConfirmation),
    ).toBe(true);
  });
  it("normalização preserva o original fora da função", () => {
    const original = "Cobrei Quatrocentos e Cinquenta";
    const r = interpretPortuguese(original);
    expect(r.originalTranscript).toBe(original);
    expect(normalizePortuguese(original)).toContain("450");
  });
});

describe("interpretação semântica e contextual informal", () => {
  it("relaciona pronomes, pagamento parcial, despesa e retorno", () => {
    const r = interpretPortuguese(
      "Fui fazer um serviço na casa de Carlos hoje, cobrei 500, ele me deu 200 e disse que amanhã termina de pagar. Comprei 80 reais de material e ainda preciso voltar lá sexta pra terminar.",
      { now },
    );
    expect(r.client.value).toBe("Carlos");
    expect(r.financial.total.value).toBe(500);
    expect(r.financial.received.value).toBe(200);
    expect(r.financial.pending.value).toBe(300);
    expect(r.expenses).toEqual(
      expect.arrayContaining([expect.objectContaining({ value: 80, category: "material" })]),
    );
    expect(r.financial.expectedPaymentDate).toBe("2026-09-25");
    expect(r.schedule[0]?.date).toBe("2026-09-25");
    expect(r.tasks.some((x) => /Finalizar/.test(x.description))).toBe(true);
  });

  it("trata acerto de saldo como pagamento de serviço existente", () => {
    const r = interpretPortuguese("João acertou comigo os 300 que faltavam.", {
      now,
      lastServiceId: "servico-aberto",
    });
    expect(r.client.value).toBe("Joao");
    expect(r.financial.received.value).toBe(300);
    expect(r.financial.pending.value).toBe(0);
    expect(r.suggestedActions.some((x) => x.type === "match_open_receivable_candidate")).toBe(true);
    expect(r.suggestedActions.some((x) => x.type === "upsert_service_candidate")).toBe(false);
  });

  it("entende promessa de pagamento com data relativa", () => {
    const r = interpretPortuguese("Maria ficou de me dar 150 segunda.", { now });
    expect(r.client.value).toBe("Maria");
    expect(r.financial.received.value).toBeNull();
    expect(r.financial.pending.value).toBe(150);
    expect(r.financial.expectedPaymentDate).toBe("2026-09-28");
  });

  it("separa duas despesas da mesma frase", () => {
    const r = interpretPortuguese(
      "Gastei cinquenta de gasolina e trinta no almoço.",
      { now },
    );
    expect(r.expenses).toEqual([
      expect.objectContaining({ value: 50, category: "combustível" }),
      expect.objectContaining({ value: 30, category: "alimentação" }),
    ]);
  });

  it("separa materiais comprados e calcula cada custo", () => {
    const r = interpretPortuguese(
      "Comprei três tomadas de 20 e um disjuntor de 35 pro serviço de Carlos.",
      { now },
    );
    expect(r.client.value).toBe("Carlos");
    expect(r.materials).toEqual([
      expect.objectContaining({ description: "tomadas", quantity: 3, unitPrice: 20, totalCost: 60 }),
      expect.objectContaining({ description: "disjuntor", quantity: 1, unitPrice: 35, totalCost: 35 }),
    ]);
    expect(r.expenses.map((x) => x.value)).toEqual([60, 35]);
  });
});
