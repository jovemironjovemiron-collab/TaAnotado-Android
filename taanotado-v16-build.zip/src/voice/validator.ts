import type {
  StructuredDataValidator,
  StructuredVoiceResult,
  ValidationResult,
  VoiceConflict,
} from "./contracts";
export class DeterministicValidator implements StructuredDataValidator {
  validate(r: StructuredVoiceResult): ValidationResult {
    const conflicts: VoiceConflict[] = [...r.conflicts];
    const { total, received, pending } = r.financial;
    if (
      total.value != null &&
      received.value != null &&
      pending.value != null
    ) {
      const expected = Math.max(0, total.value - received.value);
      if (Math.abs(expected - pending.value) > 0.01)
        conflicts.push({
          code: "FINANCIAL_MISMATCH",
          message: `Os valores não fecham. Você informou saldo de R$ ${pending.value.toFixed(2)}, mas pelos valores anteriores seriam R$ ${expected.toFixed(2)}.`,
          fields: [
            "financial.total",
            "financial.received",
            "financial.pending",
          ],
          expected,
          informed: pending.value,
        });
    }
    const warnings = [...r.warnings, ...conflicts.map((c) => c.message)];
    const criticalLow = [
      r.client,
      r.financial.total,
      r.financial.received,
    ].some((x) => x.value != null && x.confidence === "low");
    return {
      valid: conflicts.length === 0,
      warnings,
      conflicts,
      requiresConfirmation: true || criticalLow,
    };
  }
}
