import type {
  ConfidenceLevel,
  StructuredVoiceResult,
  VoiceContext,
  VoiceMaterial,
  VoiceTask,
} from "./contracts";
import { normalizePortuguese, parseMoney } from "./normalizer";
import { resolveRelativeDate } from "./dateResolver";
import { DeterministicValidator } from "./validator";
import { SafeActionPlanner } from "./actionPlanner";
import {
  clauseForPaymentPromise,
  clauseForReturn,
  extractMultipleExpenses,
  extractPaymentMeaning,
  extractPurchasedMaterials,
  inferClient,
  inferIntentSemantically,
} from "./semanticFallback";
const cap = (s: string) =>
  s
    .split(" ")
    .map((x) => x.charAt(0).toUpperCase() + x.slice(1))
    .join(" ");
const val = (t: string, rx: RegExp) => {
  const m = t.match(rx);
  return m ? parseMoney(m[1]) : null;
};
const conf = (v: unknown, e?: string): ConfidenceLevel =>
  v == null ? "missing" : e ? "high" : "medium";
export function interpretPortuguese(
  original: string,
  context: VoiceContext = {},
): StructuredVoiceResult {
  const t = normalizePortuguese(original);
  const intent = inferIntentSemantically(t);
  const paymentMeaning = extractPaymentMeaning(t);
  const total =
    val(
      t,
      /(?:por|cobrei|servico(?: de [a-z ]+)?|valor(?: total)?(?: de)?)\s*(\d+(?:\.\d{1,2})?)/,
    ) ?? val(t, /(?:dos|de)\s*(\d+(?:\.\d{1,2})?)\s*(?:reais)?/);
  const received = /(pagou tudo|recebi tudo|quitou)/.test(t)
    ? total
    : paymentMeaning.received ?? val(
        t,
        /(?:recebi|pagou|me pagou|ele deu|ela deu|deu|entrada de)(?: mais)?\s*(\d+(?:\.\d{1,2})?)/,
      );
  const informedPending =
    paymentMeaning.promised ??
    (paymentMeaning.isSettlement
      ? 0
      : val(
          t,
          /(?:ficou devendo|deve|devendo|pendente|ficou faltando|faltam?|falta receber)(?: o valor de)?\s*(\d+(?:\.\d{1,2})?)/,
        ));
  const pending =
    informedPending ??
    (total != null && received != null ? Math.max(0, total - received) : null);
  const inferredClient = inferClient(t, context.lastClientName);
  const client = inferredClient.value;
  const known = [
    "instalacao",
    "pintura",
    "manutencao",
    "conserto",
    "limpeza",
    "montagem",
    "venda",
    "visita tecnica",
    "troca de chuveiro",
    "instalacao de tomada",
  ];
  const service =
    known.find((x) => t.includes(x)) ||
    t.match(/servico de ([a-z ]+?)(?=\s+(?:para|por|no|na)|[.,]|$)/)?.[1] ||
    (/\b(servico|trabalho)\b/.test(t) ? "serviço" : null) ||
    null;
  let expenses = extractMultipleExpenses(t);
  if (!expenses.length) {
    for (const m of t.matchAll(
      /(?:gastei|despesa(?: de)?|custo(?: de)?)\s*(\d+(?:\.\d{1,2})?)(?:\s*(?:reais)?\s*(?:de|com|no|em)?\s*([a-z]+))?/g,
    ))
      expenses.push({
        value: parseMoney(m[1]),
        category: m[2] || "outros",
        evidence: m[0],
      });
  }
  const payments =
    received != null
      ? [
          {
            value: received,
            method: /\bpix\b/.test(t)
              ? "Pix"
              : /dinheiro/.test(t)
                ? "Dinheiro"
                : /cartao/.test(t)
                  ? "Cartão"
                  : null,
            evidence:
              t.match(
                /(?:recebi|pagou|deu).*?(?:pix|dinheiro|cartao|\d+)/,
              )?.[0] || "pagamento",
          },
        ]
      : [];
  const purchasedMaterials = extractPurchasedMaterials(t);
  const materials: VoiceMaterial[] = [...purchasedMaterials];
  for (const m of t.matchAll(
    /(?:comprar|preciso de|preciso comprar)\s+(\d+)?\s*(metros?|pecas?|unidades?|tomadas?|cabos?)?\s*(?:de\s+)?([a-z][a-z ]+?)(?=\s+(?:e|para|amanha|hoje)|[.,]|$)/g,
  ))
    materials.push({
      quantity: m[1] ? Number(m[1]) : null,
      unit: m[2] || null,
      description: (m[3] || m[2] || "").trim(),
      purchased: false,
    });
  const returnClause = clauseForReturn(t);
  const paymentPromiseClause = clauseForPaymentPromise(t);
  const date = resolveRelativeDate(returnClause || t, context.now);
  const paymentDate = paymentPromiseClause
    ? resolveRelativeDate(paymentPromiseClause, context.now)
    : null;
  const schedule = date.date
    ? [
        {
          date: date.date,
          period: date.period,
          time: date.time,
          description: /\b(volto|voltar)\b/.test(t)
            ? "Retorno ao cliente"
            : "Compromisso",
        },
      ]
    : [];
  const tasks: VoiceTask[] = [];
  if (/\b(terminar|finalizar)\b/.test(t))
    tasks.push({
      description: service ? `Finalizar ${service}` : "Finalizar serviço",
      dueDate: date.date,
      completed: false,
    });
  for (const m of materials)
    tasks.push({
      description: `Comprar ${[m.quantity, m.unit, m.description].filter(Boolean).join(" ")}`,
      dueDate: date.date,
      completed: false,
    });
  const conflicts: StructuredVoiceResult["conflicts"] = [];
  const warnings: string[] = [];
  const missingInformation: string[] = [];
  if (!client) missingInformation.push("client");
  if (!original.trim()) warnings.push("Nenhuma fala foi identificada.");
  if (!service && ["new_service", "mixed"].includes(intent))
    missingInformation.push("service");
  if (total == null && /servico|fiz|cobrei/.test(t))
    missingInformation.push("financial.total");
  const fingerprint = simpleHash(`${t}|${context.lastServiceId || ""}`);
  const result: StructuredVoiceResult = {
    schemaVersion: 1,
    intent,
    originalTranscript: original,
    normalizedTranscript: t,
    client: {
      value: client,
      confidence: client
        ? inferredClient.contextual
          ? "medium"
          : "high"
        : "missing",
      evidence: inferredClient.evidence,
    },
    service: {
      value: service ? cap(service) : null,
      confidence: conf(service, service || undefined),
      evidence: service || undefined,
    },
    financial: {
      total: {
        value: total,
        confidence: conf(total, total != null ? "valor" : undefined),
      },
      received: {
        value: received,
        confidence: conf(received, received != null ? "pagamento" : undefined),
      },
      pending: {
        value: pending,
        confidence: conf(
          pending,
          informedPending != null ? "saldo informado" : undefined,
        ),
      },
      estimatedProfit:
        total != null
          ? total - expenses.reduce((a, b) => a + b.value, 0)
          : null,
      expectedPaymentDate: paymentDate?.date || null,
    },
    expenses,
    payments,
    materials,
    tasks,
    schedule,
    notes: original ? [original] : [],
    confidence: 0,
    warnings,
    missingInformation,
    conflicts,
    suggestedActions: [],
    fingerprint,
  };
  const fields = [
    result.client,
    result.service,
    result.financial.total,
    result.financial.received,
    result.financial.pending,
  ];
  result.confidence =
    fields
      .filter((x) => x.value != null)
      .reduce(
        (a, x) =>
          a +
          (x.confidence === "high"
            ? 1
            : x.confidence === "medium"
              ? 0.65
              : 0.25),
        0,
      ) / Math.max(1, fields.filter((x) => x.value != null).length);
  const validation = new DeterministicValidator().validate(result);
  result.conflicts = validation.conflicts;
  result.warnings = validation.warnings;
  result.suggestedActions = new SafeActionPlanner().plan(result, context);
  return result;
}
function simpleHash(s: string) {
  let h = 2166136261;
  for (let i = 0; i < s.length; i++) {
    h ^= s.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return (h >>> 0).toString(16);
}
