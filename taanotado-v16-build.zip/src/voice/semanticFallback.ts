import type { VoiceExpense, VoiceIntent, VoiceMaterial } from "./contracts";
import { parseMoney } from "./normalizer";

const paymentSignals = ["pag", "receb", "deu", "acert", "quit", "pix", "entrada"];
const expenseSignals = ["gast", "comprei", "paguei", "custou", "despesa", "saiu"];
const serviceSignals = ["servico", "trabalho", "instal", "pint", "consert", "manut", "mont"];
const scheduleSignals = [
  "volt",
  "retorn",
  "visita",
  "encontr",
  "passar la",
  "amanha",
  "segunda",
  "terca",
  "quarta",
  "quinta",
  "sexta",
  "sabado",
  "domingo",
];
const taskSignals = ["preciso", "falta fazer", "termin", "finaliz", "buscar", "ligar", "mandar"];
const hasAny = (text: string, signals: string[]) =>
  signals.some((s) => text.includes(s));
const score = (text: string, signals: string[]) =>
  signals.reduce((n, s) => n + (text.includes(s) ? 1 : 0), 0);

export function inferIntentSemantically(text: string): VoiceIntent {
  if (/^\s*(quem|quanto|quais|qual|tenho|o que|quando)\b/.test(text))
    return "query";
  if (hasAny(text, ["cancela", "apaga", "desfaz", "nao salva", "ignora isso"]))
    return "undo";
  if (hasAny(text, ["nao foi", "corrige", "correcao", "quis dizer", "na verdade"]))
    return "correction";
  const scores = {
    new_service: score(text, serviceSignals),
    payment: score(text, paymentSignals),
    expense: score(text, expenseSignals),
    schedule: score(text, scheduleSignals),
    task: score(text, taskSignals),
  };
  const active = Object.entries(scores).filter(([, v]) => v > 0);
  if (active.length > 1) return "mixed";
  return (active.sort((a, b) => b[1] - a[1])[0]?.[0] as VoiceIntent) || "unknown";
}

const title=(s:string)=>s.split(/\s+/).map(x=>x.charAt(0).toUpperCase()+x.slice(1)).join(" ");
const invalidNames=new Set(["ele","ela","hoje","amanha","servico","trabalho","material"]);
export function inferClient(text:string,lastClientName?:string):{value:string|null;evidence?:string;contextual:boolean}{
  const patterns = [
    /(?:casa (?:de|do|da)|para|pro servico de|para o servico de|cliente)\s+([a-z]+(?:\s+(?!por\b|hoje\b|ontem\b|amanha\b)[a-z]+)?)(?=\s+(?:por|hoje|ontem|amanha|que|e|me|vai|ficou)|[.,]|$)/,
    /^([a-z]+(?:\s+(?!me\b)[a-z]+)?)\s+(?:me\s+)?(?:pagou|deu|acertou|ficou|vai)/,
  ];
  for(const p of patterns){const m=text.match(p);if(m&&!invalidNames.has(m[1]))return{value:title(m[1]),evidence:m[0],contextual:false}}
  if(lastClientName&&/\b(ele|ela|la|o cliente|a cliente)\b/.test(text))return{value:lastClientName,evidence:"referência contextual",contextual:true};
  return{value:null,contextual:false};
}

export function extractPaymentMeaning(text:string){
  const completed=text.match(/(?:acertou(?: comigo)?|quitou|pagou|me deu|ele me deu|ela me deu|recebi)(?:\s+(?:comigo|os|as|mais|o valor de|de))?\s*(\d+(?:\.\d{1,2})?)/);
  const promised=text.match(/(?:ficou de (?:me )?dar|vai (?:me )?dar|prometeu pagar|termina de pagar)(?:\s*(?:os|as|o valor de))?\s*(\d+(?:\.\d{1,2})?)?/);
  const missing=text.match(/(\d+(?:\.\d{1,2})?)\s+que faltavam/)||text.match(/(?:faltam?|devendo|pendente)\s*(\d+(?:\.\d{1,2})?)/);
  return{received:completed?parseMoney(completed[1]):null,promised:promised?(promised[1]?parseMoney(promised[1]):missing?parseMoney(missing[1]):null):null,explicitPending:missing?parseMoney(missing[1]):null,isSettlement:!!completed&&/acertou|quitou|que faltavam/.test(text),evidence:completed?.[0]||promised?.[0]};
}

const categoryOf=(s:string)=>/gasolina|combustivel|diesel|alcool/.test(s)?"combustível":/almoco|janta|lanche|comida|alimentacao/.test(s)?"alimentação":/material|tomada|cabo|fio|disjuntor|peca/.test(s)?"material":"outros";
export function extractMultipleExpenses(text:string):VoiceExpense[]{
  const out:VoiceExpense[]=[];const purchaseItems=extractPurchasedMaterials(text);if(purchaseItems.length){for(const m of purchaseItems)if(m.totalCost!=null)out.push({value:m.totalCost,category:"material",evidence:`${m.quantity} ${m.description} de ${m.unitPrice}`});return out}
  const clauses=text.replace(/(\d)\.(\d{2})\b/g,"$1¤$2")
    .split(/[,.!?;]|\s+e\s+(?=\d)/).map(x=>x.replace(/¤/g,".").trim()).filter(Boolean);let expenseContext=false;
  for (const clause of clauses) {
    if (hasAny(clause, paymentSignals) && !hasAny(clause, expenseSignals)) {
      expenseContext = false;
      continue;
    }
    if (hasAny(clause, expenseSignals)) expenseContext = true;
    if (!expenseContext) continue;
    const amount = clause.match(/(\d+(?:\.\d{1,2})?)/);
    if (!amount) continue;
    const value = parseMoney(amount[1]);
    out.push({ value, category: categoryOf(clause), evidence: clause });
  }
  return out;
}

export function extractPurchasedMaterials(text:string):Array<VoiceMaterial&{unitPrice:number|null;totalCost:number|null}>{
  if(!/\b(comprei|comprado|peguei)\b/.test(text))return[];const out:Array<VoiceMaterial&{unitPrice:number|null;totalCost:number|null}>=[];
  const rx=/(\d+)\s+([a-z]+(?:\s+[a-z]+)?)\s+(?:de|a)\s+(\d+(?:\.\d{1,2})?)(?=\s*(?:reais|cada|e|pro|para|$))/g;for(const m of text.matchAll(rx)){const quantity=Number(m[1]),unitPrice=parseMoney(m[3]);out.push({quantity,unit:null,description:m[2].trim(),purchased:true,unitPrice,totalCost:quantity*unitPrice})}return out;
}

export function clauseForReturn(text:string){const clauses=text.split(/[,.!?;]/).map(x=>x.trim());return clauses.find(c=>hasAny(c,scheduleSignals))||null}
export function clauseForPaymentPromise(text:string){const clauses=text.split(/[,.!?;]/).map(x=>x.trim());return clauses.find(c=>/termina de pagar|ficou de .*dar|vai .*pagar|prometeu/.test(c))||null}
