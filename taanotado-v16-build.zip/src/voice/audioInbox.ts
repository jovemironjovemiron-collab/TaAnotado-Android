export type AudioEntryStatus =
  | "received"
  | "transcribing"
  | "interpreting"
  | "awaiting_confirmation"
  | "organized"
  | "error";
export interface AudioEntry {
  id: string;
  createdAt: string;
  status: AudioEntryStatus;
  durationSeconds: number;
  attempts: number;
  error?: string;
  originalTranscript?: string;
  normalizedTranscript?: string;
  fingerprint?: string;
  source?: "browser_speech" | "recorded_audio" | "manual";
}
const DB = "organizae-audio-v1",
  STORE = "entries";
function open() {
  return new Promise<IDBDatabase>((resolve, reject) => {
    const q = indexedDB.open(DB, 1);
    q.onupgradeneeded = () => {
      if (!q.result.objectStoreNames.contains(STORE))
        q.result.createObjectStore(STORE, { keyPath: "id" });
    };
    q.onsuccess = () => resolve(q.result);
    q.onerror = () => reject(q.error);
  });
}
export async function saveAudioEntry(entry: AudioEntry, audio: Blob) {
  const db = await open();
  return new Promise<void>((resolve, reject) => {
    const tx = db.transaction(STORE, "readwrite");
    tx.objectStore(STORE).put({ ...entry, audio });
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
  });
}
export async function listAudioEntries(): Promise<AudioEntry[]> {
  const db = await open();
  return new Promise((resolve, reject) => {
    const q = db.transaction(STORE).objectStore(STORE).getAll();
    q.onsuccess = () =>
      resolve(
        q.result
          .map(({ audio: _, ...x }: any) => x)
          .sort((a: any, b: any) => b.createdAt.localeCompare(a.createdAt)),
      );
    q.onerror = () => reject(q.error);
  });
}
export async function updateAudioEntry(id: string, changes: Partial<AudioEntry>) {
  const db = await open();
  return new Promise<void>((resolve, reject) => {
    const tx = db.transaction(STORE, "readwrite");
    const store = tx.objectStore(STORE);
    const request = store.get(id);
    request.onsuccess = () => {
      if (request.result) store.put({ ...request.result, ...changes, id });
    };
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
  });
}
