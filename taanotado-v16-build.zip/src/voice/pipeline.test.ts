import { describe, expect, it, vi } from "vitest";
import { VoicePipeline, type PipelineStage } from "./pipeline";
import { interpretPortuguese } from "./interpreter";
import { DeterministicValidator } from "./validator";
import { SafeActionPlanner } from "./actionPlanner";
const nlu = {
  understand: async (t: string) =>
    interpretPortuguese(t, { now: new Date("2026-09-24T12:00:00-03:00") }),
};
describe("pipeline de áudio", () => {
  it("executa transcrição, interpretação, validação e confirmação", async () => {
    const stt = {
      transcribe: vi.fn(async () => ({
        original: "Serviço para João por 300",
      })),
    };
    const stages: PipelineStage[] = [];
    const p = new VoicePipeline(
      stt,
      nlu,
      new DeterministicValidator(),
      new SafeActionPlanner(),
    );
    const r = await p.process(new Blob(["audio"]), {}, (s) => stages.push(s));
    expect(stt.transcribe).toHaveBeenCalledOnce();
    expect(r.client.value).toBe("Joao");
    expect(stages).toEqual([
      "transcribing",
      "interpreting",
      "validating",
      "awaiting_confirmation",
    ]);
  });
  it("preserva erro de internet para retentativa", async () => {
    const stt = {
      transcribe: async () => {
        throw new Error("offline");
      },
    };
    const stages: PipelineStage[] = [];
    const p = new VoicePipeline(
      stt,
      nlu,
      new DeterministicValidator(),
      new SafeActionPlanner(),
    );
    await expect(
      p.process(new Blob(), {}, (s) => stages.push(s)),
    ).rejects.toThrow("offline");
    expect(stages.at(-1)).toBe("error");
  });
  it("não interpreta nem sugere ações quando a transcrição está vazia", async () => {
    const understand = vi.fn(nlu.understand);
    const p = new VoicePipeline(
      { transcribe: async () => ({ original: "  " }) },
      { understand },
      new DeterministicValidator(),
      new SafeActionPlanner(),
    );
    const stages: PipelineStage[] = [];
    await expect(p.process(new Blob(["audio"]), {}, (s) => stages.push(s)))
      .rejects.toThrow("Não foi possível transcrever");
    expect(understand).not.toHaveBeenCalled();
    expect(stages.at(-1)).toBe("error");
  });
  it("não executa repository antes da confirmação", async () => {
    const stt = { transcribe: async () => ({ original: "Carlos pagou 100" }) };
    const p = new VoicePipeline(
      stt,
      nlu,
      new DeterministicValidator(),
      new SafeActionPlanner(),
    );
    const r = await p.process(new Blob());
    expect(r.suggestedActions.length).toBeGreaterThan(0);
    expect(r.suggestedActions.every((x) => x.requiresConfirmation)).toBe(true);
  });
});
