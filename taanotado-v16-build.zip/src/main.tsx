import { reviseDraft, reviseCommand } from "./voice/revision";
import { organizeReport, type WorkReport } from "./report";
import { canUseAudio } from "./access";
import { Capacitor, registerPlugin } from "@capacitor/core";
const Microphone = registerPlugin<{ ensurePermission(): Promise<void> }>("Microphone");
import React, { useEffect, useMemo, useRef, useState } from "react";
import { createRoot } from "react-dom/client";
import {
  Home,
  Mic,
  Users,
  Wallet,
  Menu,
  ChevronRight,
  ArrowLeft,
  Pause,
  Square,
  Trash2,
  Play,
  CheckCircle2,
  AlertTriangle,
  CalendarDays,
  FileText,
  ReceiptText,
  Search,
  Plus,
  MessageCircle,
  X,
  BriefcaseBusiness,
  ShieldCheck,
  Sparkles,
  Clock3,
  Crown,
  Settings,
  LogOut,
  Download,
  Upload,
  Pencil,
} from "lucide-react";
import type { Draft, Job, Client, Status } from "./types";
import {
  emptyStore,
  id,
  interpretSpeech,
  isoToday,
  localMonth,
  load,
  money,
  save,
  type Store,
} from "./lib";
import "./style.css";
import {
  listAudioEntries,
  saveAudioEntry,
  updateAudioEntry,
  type AudioEntry,
} from "./voice/audioInbox";
import { prepareCommand, type PreparedCommand } from "./voice/command";
import { prepareAIResult, type AIExtraction } from "./voice/aiResult";

type Page =
  "home" | "record" | "clients" | "finance" | "more" | "jobs" | "budgets" | "agenda";
const professions = [
  "Eletricista",
  "Pedreiro",
  "Pintor",
  "Mecânico",
  "Técnico de ar-condicionado",
  "Instalador",
  "Encanador",
  "Diarista",
  "Montador",
  "Vendedor",
  "Técnico de informática",
  "Manutenção",
  "Construção",
  "Beleza",
  "Alimentação",
  "Transporte",
  "Serviços gerais",
  "Outro",
];
function App() {
  const [store, setStore] = useState<Store>(load);
  const [page, setPage] = useState<Page>("home");
  const [toast, setToast] = useState("");
  useEffect(() => save(store), [store]);
  const update = (fn: (s: Store) => Store) => setStore((s) => fn(s));
  const notify = (m: string) => {
    setToast(m);
    setTimeout(() => setToast(""), 2400);
  };
  if (!store.prefs.onboarded)
    return (
      <Onboard
        onDone={(profession, name) =>
          update((s) => ({
            ...s,
            prefs: { ...s.prefs, profession, name, onboarded: true },
          }))
        }
      />
    );
  const content =
    page === "home" ? (
      <Dashboard store={store} go={setPage} />
    ) : page === "record" ? (
      <Recorder
        store={store}
        update={update}
        done={() => {
          setPage("home");
          notify("Registro salvo com segurança");
        }}
      />
    ) : page === "clients" ? (
      <Clients store={store} update={update} />
    ) : page === "finance" ? (
      <Finance store={store} update={update} />
    ) : page === "jobs" ? (
      <Jobs store={store} update={update} />
    ) : page === "budgets" ? (
      <Documents store={store} update={update} notify={notify} />
    ) : page === "agenda" ? (
      <Agenda store={store} />
    ) : (
      <More store={store} update={update} go={setPage} />
    );
  return (
    <div className="app">
      <header>
        <div className="brand">
          <div className="brandmark">
            <Mic size={20} />
          </div>
          <div>
            <b>TáAnotado</b>
            <small>Você fala. A gente organiza.</small>
          </div>
        </div>
        <button className="avatar">
          {store.prefs.name?.[0]?.toUpperCase() || "OÊ"}
        </button>
      </header>
      <main>{content}</main>
      <Nav page={page} go={setPage} />
      {toast && (
        <div className="toast">
          <CheckCircle2 size={18} />
          {toast}
        </div>
      )}
    </div>
  );
}
function Onboard({ onDone }: { onDone: (p: string, n: string) => void }) {
  const [step, setStep] = useState(0),
    [name, setName] = useState(""),
    [pro, setPro] = useState("");
  return (
    <div className="onboard">
      <div className="onboard-card">
        <div className="hero-logo">
          <Mic />
        </div>
        {step === 0 ? (
          <>
            <span className="eyebrow">BEM-VINDO AO TÁANOTADO</span>
            <h1>
              Você fala.
              <br />
              <em>Seu trabalho se organiza.</em>
            </h1>
            <p>
              Clientes, serviços, pagamentos e agenda sem preencher dezenas de
              formulários.
            </p>
            <div className="flow-pill">
              Falar → Entender → Organizar → Lucrar
            </div>
            <label>
              Como podemos chamar você?
              <input
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="Seu nome"
                autoFocus
              />
            </label>
            <button
              className="primary"
              disabled={!name.trim()}
              onClick={() => setStep(1)}
            >
              Continuar <ChevronRight />
            </button>
            <button
              className="demo-link"
              onClick={() => onDone("Serviços gerais", "Visitante")}
            >
              Ver como funciona
            </button>
            <small className="privacy">
              <ShieldCheck /> Seus dados ficam neste aparelho.
            </small>
          </>
        ) : (
          <>
            <button className="back" onClick={() => setStep(0)}>
              <ArrowLeft /> Voltar
            </button>
            <span className="eyebrow">PERSONALIZE SUA EXPERIÊNCIA</span>
            <h2>Qual é a sua profissão?</h2>
            <p>
              O TáAnotado adapta exemplos e categorias para o seu dia a dia.
            </p>
            <div className="profession-grid">
              {professions.map((p) => (
                <button
                  className={pro === p ? "selected" : ""}
                  onClick={() => setPro(p)}
                  key={p}
                >
                  {p}
                </button>
              ))}
            </div>
            <button
              className="primary"
              disabled={!pro}
              onClick={() => onDone(pro, name)}
            >
              Começar agora <Sparkles />
            </button>
          </>
        )}
      </div>
    </div>
  );
}
function Dashboard({ store, go }: { store: Store; go: (p: Page) => void }) {
  const today = isoToday();
  const todayJobs = store.jobs.filter((j) => j.date === today);
  const received = store.transactions
    .filter((t) => t.type === "receita" && t.date === today)
    .reduce((a, b) => a + b.value, 0);
  const expenses = store.transactions
    .filter((t) => t.type === "despesa" && t.date === today)
    .reduce((a, b) => a + b.value, 0);
  const pending = store.jobs.reduce((a, b) => a + b.pending, 0);
  return (
    <>
      <section className="greeting">
        <div>
          <span>
            {new Date().toLocaleDateString("pt-BR", {
              weekday: "long",
              day: "2-digit",
              month: "long",
            })}
          </span>
          <h1>Olá, {store.prefs.name.split(" ")[0]}!</h1>
          <p>O que vamos organizar hoje?</p>
        </div>
        <div className="plan">
          GRÁTIS · TESTE
        </div>
      </section>
      <button className="voice-cta" onClick={() => go("record")}>
        <span className="mic-ring">
          <Mic />
        </span>
        <span>
          <b>Falar com o TáAnotado</b>
          <small>Serviço, pagamento, despesa ou lembrete</small>
        </span>
        <ChevronRight />
      </button>
      <h3 className="section-title">Resumo de hoje</h3>
      <div className="metrics">
        <Metric label="Recebido" value={money(received)} tone="green" />
        <Metric label="Gastos" value={money(expenses)} tone="red" />
        <Metric label="Lucro" value={money(received - expenses)} tone="blue" />
        <Metric label="A receber" value={money(pending)} tone="gold" />
      </div>
      <div className="section-head">
        <h3>Serviços recentes</h3>
        <button onClick={() => go("jobs")}>Ver todos</button>
      </div>
      {store.jobs.length ? (
        <div className="list">
          {store.jobs
            .slice(-3)
            .reverse()
            .map((j) => (
              <JobRow key={j.id} job={j} />
            ))}
        </div>
      ) : (
        <Empty
          icon={<BriefcaseBusiness />}
          title="Seu primeiro serviço começa aqui"
          text="Toque no microfone e conte o trabalho que realizou."
          action={() => go("record")}
        />
      )}
      <div className="quick">
        <button onClick={() => go("budgets")}>
          <FileText />
          <span>
            <b>Novo orçamento</b>
            <small>Crie e compartilhe</small>
          </span>
        </button>
        <button onClick={() => go("budgets")}>
          <ReceiptText />
          <span>
            <b>Novo recibo</b>
            <small>Gere em segundos</small>
          </span>
        </button>
      </div>
      {todayJobs.length > 0 && (
        <p className="subtle">
          {todayJobs.length} serviço(s) registrado(s) hoje
        </p>
      )}
    </>
  );
}
function Metric({
  label,
  value,
  tone,
}: {
  label: string;
  value: string;
  tone: string;
}) {
  return (
    <div className={`metric ${tone}`}>
      <small>{label}</small>
      <b>{value}</b>
    </div>
  );
}
function Recorder({
  store,
  update,
  done,
}: {
  store: Store;
  update: (f: (s: Store) => Store) => void;
  done: () => void;
}) {
  const [stage, setStage] = useState<
    "ready" | "recording" | "reviewAudio" | "processing" | "confirm"
  >("ready");
  const [seconds, setSeconds] = useState(0),
    [text, setText] = useState(""),
    [draft, setDraft] = useState<Draft | null>(null);
  const [mode, setMode] = useState<"voice" | "text">("voice");
  const [textLayout, setTextLayout] = useState<"report" | "free">("report");
  const [report, setReport] = useState<WorkReport>({ client: "", phone: "", address: "", profession: store.prefs.profession,
    email: "", reference: "", paymentMethod: "", paymentDue: "", deadline: "", startTime: "", endTime: "", tasks: "", warranty: "", budgetValidity: "",
    service: "", date: isoToday(), total: "", received: "", expense: "", materials: "", nextVisit: "", nextVisitTime: "", status: "em andamento", notes: "" });
  const reportField = (key: keyof WorkReport, value: string) => setReport((old) => ({ ...old, [key]: value }));
  const [command, setCommand] = useState<PreparedCommand | null>(null);
  const [selectedJobId, setSelectedJobId] = useState("");
  const revisionTarget = useRef<Draft | null>(null);
  const revisionCommand = useRef<PreparedCommand | null>(null);
  const [revisionActive, setRevisionActive] = useState(false);
  const [previousRevision, setPreviousRevision] = useState<Draft | null>(null);
  const [paused, setPaused] = useState(false);
  const [blob, setBlob] = useState<Blob | null>(null);
  const timer = useRef<number | null>(null),
    media = useRef<MediaRecorder | null>(null),
    chunks = useRef<Blob[]>([]),
    starting = useRef(false),
    startedAt = useRef(0),
    pausedAt = useRef(0),
    pausedMs = useRef(0),
    recordedDuration = useRef(0),
    recordedEntryId = useRef(""),
    recordingSaved = useRef<Promise<void>>(Promise.resolve());
  useEffect(
    () => () => {
      if (timer.current) clearInterval(timer.current);
      if (media.current?.state === "recording" || media.current?.state === "paused") media.current.stop();
    },
    [],
  );
  useEffect(() => {
    const handleVisibility = () => {
      if (document.hidden && media.current?.state === "recording") {
        media.current.pause();
        pausedAt.current = Date.now();
        if (timer.current) clearInterval(timer.current);
        setPaused(true);
      }
    };
    document.addEventListener("visibilitychange", handleVisibility);
    return () =>
      document.removeEventListener("visibilitychange", handleVisibility);
  }, []);
  const start = async () => {
    if (starting.current || media.current?.state === "recording") return;
    if (!canUseAudio({ active: false, verifiedByServer: false })) return alert("Assine um plano para organizar por áudio.");
    starting.current = true;
    setSeconds(0);
    setPaused(false);
    setBlob(null);
    setText("");
    if (!revisionTarget.current) setDraft(null);
    setCommand(null);
    recordedDuration.current = 0;
    pausedAt.current = 0;
    pausedMs.current = 0;
    recordedEntryId.current = "";
    recordingSaved.current = Promise.resolve();
    try {
      if (Capacitor.isNativePlatform()) await Microphone.ensurePermission();
      if (!navigator.mediaDevices?.getUserMedia || !window.isSecureContext)
        throw new Error("Este ambiente não permite gravação. Atualize o aplicativo e o Android System WebView.");
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      chunks.current = [];
      const mimeType = ["audio/webm;codecs=opus", "audio/webm", "audio/mp4"].find((type) => MediaRecorder.isTypeSupported(type));
      let recorder: MediaRecorder;
      try { recorder = new MediaRecorder(stream, mimeType ? { mimeType } : undefined); }
      catch (error) { stream.getTracks().forEach((track) => track.stop()); throw error; }
      media.current = recorder;
      startedAt.current = Date.now();
      recorder.ondataavailable = (e) => chunks.current.push(e.data);
      recorder.onstop = async () => {
        const recorded = new Blob(chunks.current, { type: recorder.mimeType || "audio/webm" });
        const paused = pausedMs.current + (pausedAt.current ? Date.now() - pausedAt.current : 0);
        recordedDuration.current = Math.floor((Date.now() - startedAt.current - paused) / 1000);
        setBlob(recorded);
        const entryId = id();
        recordedEntryId.current = entryId;
        try {
          recordingSaved.current = saveAudioEntry(
            {
              id: entryId,
              createdAt: new Date().toISOString(),
              status: "received",
              source: "recorded_audio",
              durationSeconds: recordedDuration.current,
              attempts: 0,
            },
            recorded,
          );
          await recordingSaved.current;
        } catch {
          localStorage.setItem(
            "organizae-last-audio-pending",
            new Date().toISOString(),
          );
        }
        stream.getTracks().forEach((t) => t.stop());
      };
      recorder.onerror = () => {
        if (timer.current) clearInterval(timer.current);
        setPaused(true);
      };
      recorder.start();
    } catch (error) {
      const name = error instanceof Error ? error.name : "";
      alert(name === "NotAllowedError" ? "O Android ou WebView bloqueou o microfone. Confira a permissão e o acesso ao microfone nas configurações de privacidade." : name === "NotReadableError" ? "Microfone ocupado. Feche outros gravadores ou chamadas e tente novamente." : error instanceof Error ? error.message : "Não foi possível iniciar a gravação.");
      setStage("ready");
      starting.current = false;
      return;
    }
    starting.current = false;
    setMode("voice");
    setStage("recording");
    timer.current = window.setInterval(() => setSeconds((s) => s + 1), 1000);
  };
  const stop = () => {
    if (timer.current) clearInterval(timer.current);
    if (media.current?.state === "recording" || media.current?.state === "paused") media.current.stop();
    setStage("reviewAudio");
  };
  const togglePause = () => {
    if (!media.current) return;
    if (media.current.state === "recording") {
      media.current.pause();
      pausedAt.current = Date.now();
      if (timer.current) clearInterval(timer.current);
      setPaused(true);
    } else if (media.current.state === "paused") {
      pausedMs.current += Date.now() - pausedAt.current;
      pausedAt.current = 0;
      media.current.resume();
      timer.current = window.setInterval(() => setSeconds((s) => s + 1), 1000);
      setPaused(false);
    }
  };
  const process = async () => {
    if (mode === "voice") {
      if (!blob || blob.size < 1024 || blob.size > 12 * 1024 * 1024 ||
        recordedDuration.current < 1 || recordedDuration.current > 120 ||
        !["audio/webm", "audio/mp4", "audio/wav"].includes(blob.type.split(";")[0])) {
        alert("Gravação vazia, longa demais ou em formato não aceito. Grave novamente.");
        return;
      }
      setStage("processing");
      try {
        await recordingSaved.current.catch(() => {});
        if (recordedEntryId.current)
          void updateAudioEntry(recordedEntryId.current, { status: "transcribing", attempts: 1 }).catch(() => {});
        const audioHash = [...new Uint8Array(await crypto.subtle.digest("SHA-256", await blob.arrayBuffer()))]
          .map((n) => n.toString(16).padStart(2, "0")).join("");
        const body = new FormData();
        body.append("audio", blob, `gravacao.${blob.type.includes("mp4") ? "mp4" : blob.type.includes("wav") ? "wav" : "webm"}`);
        body.append("durationSeconds", String(recordedDuration.current));
        body.append("profession", store.prefs.profession);
        body.append("today", isoToday());
        body.append("revision", revisionTarget.current || revisionCommand.current ? "true" : "false");
        const server = localStorage.getItem("taanotado-voice-server") || "";
        if (Capacitor.isNativePlatform() && !server)
          throw new Error("O serviço de voz ainda não foi conectado a este aplicativo. Configure o endereço em Mais > Configurações. Sua gravação foi preservada.");
        const endpoint = server ? new URL("/api/voice/process", server).href : "/api/voice/process";
        const response = await fetch(endpoint, { method: "POST", body, credentials: server ? "include" : "same-origin", signal: AbortSignal.timeout(90000) });
        const data = await response.json();
        if (!response.ok) {
          if (typeof data.transcript === "string") setText(data.transcript);
          throw new Error(data.message || "Não foi possível processar este áudio.");
        }
        if (data.audioSha256 !== audioHash || !data.transcript?.trim() || !data.interpretation)
          throw new Error("A resposta não corresponde à gravação. Tente novamente.");
        const definitive = data.transcript.trim();
        setText(definitive);
        if (revisionCommand.current) {
          const revised = reviseCommand(revisionCommand.current, data.interpretation as AIExtraction, definitive, store);
          setCommand(revised);
          setDraft(null);
          setSelectedJobId(revised.kind === "payment" && revised.jobIds.length === 1 ? revised.jobIds[0] : "");
          revisionCommand.current = null;
          setRevisionActive(false);
          setStage("confirm");
          return;
        }
        if (revisionTarget.current) {
          const original = revisionTarget.current;
          const revised = reviseDraft(original, data.interpretation as AIExtraction, definitive);
          setPreviousRevision(original);
          setDraft(revised);
          setCommand(null);
          revisionTarget.current = null;
          setRevisionActive(false);
          setStage("confirm");
          return;
        }
        const prepared = prepareAIResult(definitive, data.interpretation as AIExtraction, store);
        setCommand(prepared.command);
        setDraft(prepared.draft);
        setSelectedJobId(prepared.command.kind === "payment" && prepared.command.jobIds.length === 1
          ? prepared.command.jobIds[0] : "");
        if (recordedEntryId.current) void updateAudioEntry(recordedEntryId.current, {
          status: "awaiting_confirmation", originalTranscript: definitive,
          normalizedTranscript: definitive, error: undefined,
        }).catch(() => {});
        setStage("confirm");
      } catch (error) {
        const message = error instanceof Error ? error.message : "Não foi possível processar o áudio.";
        if (recordedEntryId.current) void updateAudioEntry(recordedEntryId.current,
          { status: "error", error: message }).catch(() => {});
        alert(`${message} O áudio continua disponível para tentar novamente.`);
        setStage("reviewAudio");
      }
      return;
    }
    if (textLayout === "report") {
      try {
        const organized = organizeReport(report);
        setDraft(organized);
        setCommand(null);
        setText(`Cliente: ${organized.client}\nFunção: ${organized.category || "Não informada"}\nServiço: ${organized.service}\nData: ${organized.date}\nTotal: ${organized.total}\nRecebido: ${organized.received}\nPendente: ${organized.pending}\nDespesas: ${organized.expenses[0]}\nMateriais: ${organized.materials.join(", ")}\nObservações: ${organized.notes}`);
        setStage("confirm");
      } catch (error) { alert(error instanceof Error ? error.message : "Confira o relatório."); }
      return;
    }
    const final = text.trim();
    if (!final) {
      alert("Escreva o que aconteceu antes de organizar.");
      return;
    }
    const prepared = prepareCommand(final, store);
    setStage("processing");
    setCommand(prepared);
    setSelectedJobId(prepared.kind === "payment" && prepared.jobIds.length === 1 ? prepared.jobIds[0] : "");
    setDraft(prepared.kind === "service" ? interpretSpeech(final) : null);
    setStage("confirm");
  };
  const saveDraft = () => {
    if (!draft) return;
    const clientName = draft.client?.trim();
    const description = draft.service?.trim();
    if (!clientName || !description) return alert("Informe cliente e serviço antes de salvar.");
    if (draft.total == null) return alert("Informe o valor total, inclusive zero se este serviço for gratuito.");
    if ([draft.total, draft.received, draft.pending, ...draft.expenses].some((n) => n != null && (!Number.isFinite(n) || n < 0)))
      return alert("Confira os valores antes de salvar.");
    const matches = store.clients.filter((c) => c.name.localeCompare(clientName, "pt-BR", { sensitivity: "base" }) === 0);
    if (matches.length > 1) return alert("Há clientes com este nome. Identifique o cliente correto antes de salvar.");
    let client = matches[0];
    if (!client) {
      client = { id: id(), name: clientName, phone: draft.phone, address: draft.address };
    }
    const total = draft.total || 0,
      received = draft.received || 0,
      expenses = draft.expenses.reduce((a, b) => a + b, 0),
      pending = draft.pending ?? Math.max(0, total - received);
    if (draft.status === "pago" && pending > 0) return alert("Este serviço ainda tem saldo pendente. Corrija a situação ou os valores.");
    if (received > total || Math.abs(total - received - pending) > 0.01)
      return alert("O total, o recebido e o saldo pendente não fecham. Corrija antes de salvar.");
    if (draft.nextVisit && draft.nextVisitTime && store.jobs.some((j) =>
      j.nextVisit === draft.nextVisit && j.time === draft.nextVisitTime))
      return alert("Já existe um retorno neste dia e horário. Confira a agenda antes de salvar.");
    const job: Job = {
      id: id(),
      clientId: client.id,
      clientName,
      description,
      category: draft.category || store.prefs.profession,
      date: draft.date || isoToday(),
      total,
      received,
      pending,
      expenses,
      materials: draft.materials,
      notes: draft.notes,
      status: (draft.status || "em andamento") as Status,
      nextVisit: draft.nextVisit,
      time: draft.nextVisitTime || undefined,
      createdAt: new Date().toISOString(),
    };
    update((s) => ({
      ...s,
      auditEvents: [...s.auditEvents, { id: id(), createdAt: new Date().toISOString(),
        source: mode === "voice" ? "audio" : "texto", transcript: text.trim(),
        action: "serviço", recordId: job.id }],
      clients: s.clients.some((c) => c.id === client!.id)
        ? s.clients.map((c) => c.id === client!.id ? { ...c, ...(draft.phone ? { phone: draft.phone } : {}), ...(draft.address ? { address: draft.address } : {}) } : c)
        : [...s.clients, client!],
      jobs: [...s.jobs, job],
      transactions: [
        ...s.transactions,
        ...(received
          ? [
              {
                id: id(),
                type: "receita" as const,
                description: `Pagamento de ${clientName}`,
                value: received,
                date: job.date,
                jobId: job.id,
                paymentMethod: draft.paymentMethod || command?.result.payments[0]?.method || null,
              },
            ]
          : []),
        ...(expenses
          ? [
              {
                id: id(),
                type: "despesa" as const,
                description: `Material — ${clientName}`,
                value: expenses,
                date: job.date,
                jobId: job.id,
              },
            ]
          : []),
      ],
      usage: {
        ...s.usage,
        recordings: s.usage.recordings + 1,
        minutes: s.usage.minutes + Math.max(1, Math.ceil(seconds / 60)),
        aiCalls: s.usage.aiCalls,
      },
    }));
    if (mode === "voice" && recordedEntryId.current)
      void updateAudioEntry(recordedEntryId.current, { status: "organized" }).catch(() => {});
    done();
  };
  const saveOtherCommand = () => {
    if (!command) return;
    if (command.kind === "payment") {
      const job = store.jobs.find((j) => j.id === selectedJobId && command.jobIds.includes(j.id));
      if (!job || command.amount <= 0 || command.amount > job.pending)
        return alert("Escolha a pendência correta. O pagamento não pode superar o saldo registrado.");
      update((s) => ({ ...s,
        auditEvents: [...s.auditEvents, { id: id(), createdAt: new Date().toISOString(),
          source: mode === "voice" ? "audio" : "texto", transcript: text.trim(),
          action: "pagamento", recordId: job.id }],
        jobs: s.jobs.map((j) => j.id === job.id ? {
          ...j, received: j.received + command.amount, pending: j.pending - command.amount,
          status: j.pending === command.amount ? "pago" : "aguardando pagamento",
        } : j),
        transactions: [...s.transactions, { id: id(), type: "receita", description: `Pagamento de ${job.clientName}`,
          value: command.amount, date: isoToday(), jobId: job.id,
          paymentMethod: command.result.payments[0]?.method || null }],
      }));
      if (mode === "voice" && recordedEntryId.current)
        void updateAudioEntry(recordedEntryId.current, { status: "organized" }).catch(() => {});
      done();
    } else if (command.kind === "expense") {
      if (!(command.amount > 0)) return alert("Confira o valor da despesa.");
      const transactionId = id();
      update((s) => ({ ...s,
        auditEvents: [...s.auditEvents, { id: id(), createdAt: new Date().toISOString(),
          source: mode === "voice" ? "audio" : "texto", transcript: text.trim(),
          action: "despesa", recordId: transactionId }],
        transactions: [...s.transactions, {
        id: transactionId, type: "despesa", description: command.result.originalTranscript,
        value: command.amount, date: isoToday(),
      }] }));
      if (mode === "voice" && recordedEntryId.current)
        void updateAudioEntry(recordedEntryId.current, { status: "organized" }).catch(() => {});
      done();
    } else if (command.kind === "appointment") {
      if (store.appointments.some((a) => a.date === command.date && a.time === command.time) ||
        store.jobs.some((j) => j.nextVisit === command.date && j.time === command.time))
        return alert("Já existe um compromisso nesse dia e horário. Confira a agenda.");
      const client = store.clients.find((c) => c.id === command.clientId);
      if (!client) return alert("Cliente não encontrado. Confira antes de salvar.");
      const appointmentId = id();
      update((s) => ({ ...s,
        auditEvents: [...s.auditEvents, { id: id(), createdAt: new Date().toISOString(),
          source: mode === "voice" ? "audio" : "texto", transcript: text.trim(),
          action: "compromisso", recordId: appointmentId }],
        appointments: [...s.appointments, {
        id: appointmentId, clientId: client.id, clientName: client.name, date: command.date,
        time: command.time, description: command.result.originalTranscript,
        createdAt: new Date().toISOString(),
      }] }));
      if (mode === "voice" && recordedEntryId.current)
        void updateAudioEntry(recordedEntryId.current, { status: "organized" }).catch(() => {});
      done();
    }
  };
  if (stage === "processing")
    return (
      <div className="center-screen">
        <div className="loader">
          <Sparkles />
        </div>
        <h2>Organizando seu relato…</h2>
        <p>Identificando cliente, serviço, valores e datas.</p>
      </div>
    );
  if (stage === "confirm" && draft)
    return (
      <Confirm
        draft={draft}
        setDraft={setDraft}
        onSave={saveDraft}
        onRevise={() => { revisionTarget.current = draft; setRevisionActive(true); void start(); }}
        onUndoRevision={previousRevision ? () => { setDraft(previousRevision); setPreviousRevision(null); } : undefined}
        onBack={() => setStage("reviewAudio")}
      />
    );
  if (stage === "confirm" && command) return (
    <div className="record-page">
      <button className="back" onClick={() => setStage("reviewAudio")}><ArrowLeft /> Corrigir relato</button>
      <div className="page-title"><h1>Confira antes de salvar</h1><p>Relato: {command.result.originalTranscript}</p></div>
      {["payment", "expense", "appointment"].includes(command.kind) && <button className="secondary full" onClick={() => { revisionCommand.current = command; setRevisionActive(true); void start(); }}><Mic /> Ajustar por áudio</button>}
      <div className="form-card">
        {command.kind === "payment" && <>
          <p>Pagamento de {command.result.client.value}: <b>{money(command.amount)}</b></p>
          <label>Escolha a pendência
            <select value={selectedJobId} onChange={(e) => setSelectedJobId(e.target.value)}>
              <option value="">Selecione o serviço</option>
              {command.jobIds.map((jobId) => { const job = store.jobs.find((j) => j.id === jobId); return job &&
                <option value={jobId} key={jobId}>{job.description} — falta {money(job.pending)}</option>; })}
            </select>
          </label>
        </>}
        {command.kind === "expense" && <p>Despesa: <b>{money(command.amount)}</b>. Confira o relato acima.</p>}
        {command.kind === "appointment" && <p>Compromisso com {store.clients.find((c) => c.id === command.clientId)?.name}
          em {new Date(command.date + "T12:00").toLocaleDateString("pt-BR")} às {command.time}.</p>}
        {command.kind === "query" && <p>{command.answer}</p>}
        {command.kind === "clarify" && <p>{command.reason}</p>}
      </div>
      {(command.kind === "payment" || command.kind === "expense" || command.kind === "appointment") &&
        <button className="primary full" onClick={saveOtherCommand}><CheckCircle2 /> Confirmar e salvar</button>}
    </div>
  );
  return (
    <div className="record-page">
      <div className="page-title">
        <h1>Organizar</h1>
        <p>Fale ou digite. Você confere tudo antes de salvar.</p>
      </div>
      {revisionActive && <div className="warning"><span><b>Ajustar por áudio</b><p>Diga somente o que quer mudar. O relatório anterior será preservado até a revisão.</p><button className="secondary" onClick={() => { if (media.current?.state === "recording" || media.current?.state === "paused") media.current.stop(); if (timer.current) clearInterval(timer.current); setDraft(revisionTarget.current); if (revisionCommand.current) setCommand(revisionCommand.current); revisionCommand.current = null; revisionTarget.current = null; setRevisionActive(false); setStage("confirm"); }}>Cancelar ajuste e voltar</button></span></div>}
      <div className="mode-tabs">
        <button
          className={mode === "voice" ? "selected" : ""}
          onClick={() => setMode("voice")}
        >
          <Mic /> Falar
        </button>
        <button
          className={mode === "text" ? "selected" : ""}
          onClick={() => setMode("text")}
        >
          <FileText /> Digitar
        </button>
      </div>
      {mode === "voice" && (
        <div className={`recorder ${stage === "recording" ? "active" : ""}`}>
          <div className="waves">
            {[1, 2, 3, 4, 5, 6, 7, 8, 9].map((x) => (
              <i key={x} />
            ))}
          </div>
          <button
            className="record-button"
            onClick={stage === "recording" ? stop : start}
          >
            {stage === "recording" ? <Square fill="currentColor" /> : <Mic />}
          </button>
          <h2>
            {stage === "recording"
              ? paused
                ? "Gravação pausada"
                : "Estou ouvindo…"
              : stage === "reviewAudio"
                ? "Gravação pronta"
                : "Toque para começar"}
          </h2>
          <b className="timer">
            {String(Math.floor(seconds / 60)).padStart(2, "0")}:
            {String(seconds % 60).padStart(2, "0")}
          </b>
          <p>
            {stage === "recording"
              ? "Fale naturalmente. Diga cliente, serviço e valores."
              : "O microfone só é ativado quando você toca no botão."}
          </p>
          {stage === "recording" && (
            <button className="pause-button" onClick={togglePause}>
              {paused ? <Play /> : <Pause />} {paused ? "Continuar" : "Pausar"}
            </button>
          )}
        </div>
      )}
      {(stage === "reviewAudio" || mode === "text") && (
        <div className="audio-review">
          {mode === "voice" && blob && (
            <audio controls src={URL.createObjectURL(blob)} />
          )}
          {mode === "text" && <div className="mode-tabs">
            <button className={textLayout === "report" ? "selected" : ""} onClick={() => setTextLayout("report")}>Preencher relatório</button>
            <button className={textLayout === "free" ? "selected" : ""} onClick={() => setTextLayout("free")}>Texto livre</button>
          </div>}
          {mode === "text" && textLayout === "report" && <div className="work-report">
            <h2>Relatório do serviço</h2>
            <p>Preencha um serviço por relatório. Campos com * são obrigatórios. Confira os dados antes de salvar.</p>
            <h3>Cliente</h3>
            <Field label="Nome do cliente *" value={report.client} onChange={(v) => reportField("client", v)} />
            <Field label="Telefone / WhatsApp (opcional)" type="tel" value={report.phone} onChange={(v) => reportField("phone", v)} />
            <Field label="Endereço do serviço (opcional)" value={report.address} onChange={(v) => reportField("address", v)} />
            <Field label="E-mail do cliente (opcional)" type="email" value={report.email} onChange={(v) => reportField("email", v)} />
            <h3>Trabalho realizado</h3>
            <Field label="Referência do trabalho / número do orçamento (opcional)" value={report.reference} onChange={(v) => reportField("reference", v)} />
            <Field label="Sua função / profissão" value={report.profession} onChange={(v) => reportField("profession", v)} />
            <label>O que você fez? *<small>Descreva o trabalho realizado ou o serviço que está orçando.</small><textarea value={report.service} onChange={(e) => reportField("service", e.target.value)} placeholder="Ex.: pintei as paredes da sala" /></label>
            <Field label="Data do serviço" type="date" value={report.date} onChange={(v) => reportField("date", v)} />
            <label>Situação do serviço<select value={report.status} onChange={(e) => reportField("status", e.target.value)}>{["orçamento", "aprovado", "agendado", "em andamento", "concluído", "aguardando pagamento", "pago", "cancelado"].map((status) => <option key={status}>{status}</option>)}</select></label>
            <div className="form-grid">
              <Field label="Horário de início (opcional)" type="time" value={report.startTime} onChange={(v) => reportField("startTime", v)} />
              <Field label="Horário de término (opcional)" type="time" value={report.endTime} onChange={(v) => reportField("endTime", v)} />
            </div>
            <Field label="Prazo combinado para finalizar (opcional)" type="date" value={report.deadline} onChange={(v) => reportField("deadline", v)} />
            <h3>Valores e pagamento</h3>
            <Field label="Valor total combinado (R$) *" value={report.total} onChange={(v) => reportField("total", v)} />
            <small>Informe 0 para um serviço gratuito. Use vírgula para centavos.</small>
            <Field label="Quanto já recebeu (R$)" value={report.received} onChange={(v) => reportField("received", v)} />
            <Field label="Quanto gastou neste serviço (R$)" value={report.expense} onChange={(v) => reportField("expense", v)} />
            <p>O app calcula quanto falta receber e o lucro estimado. Recebido e despesas em branco serão considerados zero.</p>
            <label>Forma de pagamento (opcional)<select value={report.paymentMethod} onChange={(e) => reportField("paymentMethod", e.target.value)}>{["", "Pix", "Dinheiro", "Cartão", "Transferência", "Boleto", "Outro"].map((method) => <option key={method} value={method}>{method || "Não informado"}</option>)}</select></label>
            <Field label="Data combinada para receber o restante (opcional)" type="date" value={report.paymentDue} onChange={(v) => reportField("paymentDue", v)} />
            <Field label="Validade do orçamento (opcional)" type="date" value={report.budgetValidity} onChange={(v) => reportField("budgetValidity", v)} />
            <h3>Materiais e próximos passos</h3>
            <label>Materiais utilizados (opcional)<small>Um por linha: nome, quantidade, unidade e custo, se souber. Ex.: tinta — 2 latas de 18 litros — R$ 400.</small><textarea value={report.materials} onChange={(e) => reportField("materials", e.target.value)} /></label>
            <Field label="Data do próximo retorno (opcional)" type="date" value={report.nextVisit} onChange={(v) => reportField("nextVisit", v)} />
            <Field label="Horário do retorno (opcional)" type="time" value={report.nextVisitTime} onChange={(v) => reportField("nextVisitTime", v)} />
            <label>Tarefas e pendências (opcional)<small>Liste o que falta, quem fará e até quando. Será preservado nas observações do serviço.</small><textarea value={report.tasks} onChange={(e) => reportField("tasks", e.target.value)} /></label>
            <label>Garantia e condições combinadas (opcional)<textarea value={report.warranty} onChange={(e) => reportField("warranty", e.target.value)} /></label>
            <label>Outras observações<textarea value={report.notes} onChange={(e) => reportField("notes", e.target.value)} /></label>
          </div>}
          {(mode === "voice" || textLayout === "free") && <label>
            {mode === "voice" ? "Transcrição" : "Conte o que aconteceu"}{" "}
            <small>
              O TáAnotado separa cliente, valores, datas e materiais. Confira o texto reconhecido.
            </small>
            <textarea
              value={text}
              onChange={(e) => setText(e.target.value)}
              readOnly={mode === "voice"}
              placeholder={mode === "voice" ? "A transcrição do áudio aparecerá após o processamento." : "Conte o que aconteceu"}
            />
          </label>}
          <div className="row">
            {mode === "voice" && (
              <button
                className="secondary"
                onClick={() => {
                  setText("");
                  start();
                }}
              >
                <Trash2 /> Regravar
              </button>
            )}
            <button className="primary" onClick={process} disabled={mode === "voice" && !blob}>
              <Sparkles /> {mode === "text" && textLayout === "report" ? "Organizar relatório e conferir" : "Organizar agora"}
            </button>
          </div>
        </div>
      )}
      <div className="tip">
        <ShieldCheck />
        <span>
          <b>Sua privacidade vem primeiro</b>{mode === "text" ? "O relatório é organizado neste aparelho. Nada é salvo antes da sua confirmação." : "A gravação começa após seu toque. Ao organizar, o áudio será enviado ao serviço de transcrição e IA."}
        </span>
      </div>
    </div>
  );
}
function Confirm({
  draft,
  setDraft,
  onSave,
  onBack,
  onRevise,
  onUndoRevision,
}: {
  draft: Draft;
  setDraft: (d: Draft) => void;
  onSave: () => void;
  onBack: () => void;
  onRevise: () => void;
  onUndoRevision?: () => void;
}) {
  const set = (k: keyof Draft, v: any) => setDraft({ ...draft, [k]: v });
  const expense = draft.expenses.reduce((a, b) => a + b, 0),
    profit = (draft.total || 0) - expense;
  return (
    <div>
      <button className="back" onClick={onBack}>
        <ArrowLeft /> Voltar
      </button>
      <div className="page-title">
        <h1>Confira antes de salvar</h1>
        <p>Confira cada área. Nada será salvo sem sua confirmação.</p>
        <button className="secondary full" onClick={onRevise}><Mic /> Ajustar por áudio</button>
        {onUndoRevision && <button className="secondary full" onClick={onUndoRevision}>Desfazer último ajuste por áudio</button>}
      </div>
      {draft.warnings.length > 0 && (
        <div className="warning">
          <AlertTriangle />
          {draft.warnings.join(" ")}
        </div>
      )}
      <div className="form-card">
        <Field
          label="Cliente"
          value={draft.client || ""}
          onChange={(v) => set("client", v || null)}
        />
        {draft.category && <p><b>Função:</b> {draft.category}</p>}
        {draft.phone && <p><b>Telefone:</b> {draft.phone}</p>}
        {draft.address && <p><b>Endereço:</b> {draft.address}</p>}
        <Field
          label="Serviço"
          value={draft.service || ""}
          onChange={(v) => set("service", v || null)}
        />
        <div className="form-grid">
          <Field
            label="Valor total"
            type="number"
            value={draft.total ?? ""}
            onChange={(v) => set("total", Number(v))}
          />
          <Field
            label="Valor recebido"
            type="number"
            value={draft.received ?? ""}
            onChange={(v) => set("received", Number(v))}
          />
          <Field
            label="Valor pendente"
            type="number"
            value={draft.pending ?? ""}
            onChange={(v) => set("pending", Number(v))}
          />
          <Field
            label="Despesas"
            type="number"
            value={expense || ""}
            onChange={(v) => set("expenses", [Number(v)])}
          />
        </div>
        <div className="calc">
          <span>Lucro estimado do serviço</span>
          <b>{money(profit)}</b>
        </div>
        <Field
          label="Materiais e tarefas"
          value={draft.materials.join(", ")}
          onChange={(v) =>
            set("materials", v ? v.split(",").map((x) => x.trim()) : [])
          }
        />
        <div className="form-grid">
          <Field
            label="Data"
            type="date"
            value={draft.date || ""}
            onChange={(v) => set("date", v)}
          />
          <Field
            label="Próximo retorno"
            type="date"
            value={draft.nextVisit || ""}
            onChange={(v) => set("nextVisit", v || null)}
          />
          <Field label="Horário do retorno" type="time" value={draft.nextVisitTime || ""}
            onChange={(v) => set("nextVisitTime", v || null)} />
        </div>
        <label>
          Status
          <select
            value={draft.status || ""}
            onChange={(e) => set("status", e.target.value)}
          >
            {[
              "orçamento",
              "aprovado",
              "agendado",
              "em andamento",
              "concluído",
              "aguardando pagamento",
              "pago",
              "cancelado",
            ].map((x) => (
              <option key={x}>{x}</option>
            ))}
          </select>
        </label>
        <label>
          Observações
          <textarea
            value={draft.notes}
            onChange={(e) => set("notes", e.target.value)}
          />
        </label>
      </div>
      <button className="primary full" onClick={onSave}>
        <CheckCircle2 /> Confirmar e salvar
      </button>
    </div>
  );
}
function Field({
  label,
  value,
  onChange,
  type = "text",
}: {
  label: string;
  value: string | number;
  onChange: (v: string) => void;
  type?: string;
}) {
  return (
    <label>
      {label}
      <input
        type={type}
        value={value}
        onChange={(e) => onChange(e.target.value)}
      />
    </label>
  );
}
function Clients({
  store,
  update,
}: {
  store: Store;
  update: (f: (s: Store) => Store) => void;
}) {
  const [q, setQ] = useState(""),
    [adding, setAdding] = useState(false),
    [name, setName] = useState(""),
    [phone, setPhone] = useState("");
  const filtered = store.clients.filter((c) =>
    c.name.toLowerCase().includes(q.toLowerCase()),
  );
  const edit = (client: Client) => {
    const nextName = window.prompt("Nome do cliente", client.name)?.trim();
    if (!nextName) return;
    const nextPhone = window.prompt("Telefone / WhatsApp", client.phone || "")?.trim() || "";
    update((s) => ({
      ...s,
      clients: s.clients.map((c) => c.id === client.id ? { ...c, name: nextName, phone: nextPhone } : c),
      jobs: s.jobs.map((j) => j.clientId === client.id ? { ...j, clientName: nextName } : j),
      appointments: s.appointments.map((a) => a.clientId === client.id ? { ...a, clientName: nextName } : a),
    }));
  };
  const remove = (client: Client) => {
    if (store.jobs.some((j) => j.clientId === client.id)) {
      alert("Este cliente possui serviços registrados. Exclua ou ajuste os serviços antes de remover o cliente.");
      return;
    }
    if (!window.confirm(`Excluir ${client.name}?`)) return;
    update((s) => ({ ...s, clients: s.clients.filter((c) => c.id !== client.id) }));
  };
  const add = () => {
    if (!name) return;
    update((s) => ({
      ...s,
      clients: [...s.clients, { id: id(), name, phone }],
    }));
    setAdding(false);
    setName("");
    setPhone("");
  };
  return (
    <>
      <div className="page-title with-action">
        <div>
          <h1>Clientes</h1>
          <p>{store.clients.length} cliente(s) cadastrado(s)</p>
        </div>
        <button className="icon-button" onClick={() => setAdding(true)}>
          <Plus />
        </button>
      </div>
      <div className="search">
        <Search />
        <input
          value={q}
          onChange={(e) => setQ(e.target.value)}
          placeholder="Buscar cliente"
        />
      </div>
      {adding && (
        <div className="modal">
          <div>
            <button className="close" onClick={() => setAdding(false)}>
              <X />
            </button>
            <h2>Novo cliente</h2>
            <Field label="Nome" value={name} onChange={setName} />
            <Field
              label="Telefone / WhatsApp"
              value={phone}
              onChange={setPhone}
            />
            <button className="primary full" onClick={add}>
              Salvar cliente
            </button>
          </div>
        </div>
      )}
      {filtered.length ? (
        <div className="list">
          {filtered.map((c) => {
            const jobs = store.jobs.filter((j) => j.clientId === c.id);
            const pend = jobs.reduce((a, b) => a + b.pending, 0);
            return (
              <div className="client-row" key={c.id}>
                <div className="client-avatar">{c.name[0]}</div>
                <span>
                  <b>{c.name}</b>
                  <small>
                    {jobs.length} serviço(s) •{" "}
                    {pend ? `${money(pend)} pendente` : "Em dia"}
                  </small>
                  {pend > 0 && <button className="secondary" onClick={() => {
                    const message = `Olá ${c.name}, tudo bem? Passando para lembrar que há ${money(pend)} pendente dos serviços registrados. Podemos combinar o pagamento?`;
                    if (window.confirm(`Confira a mensagem antes de abrir o WhatsApp:\n\n${message}`))
                      window.open(`https://wa.me/${(c.phone || "").replace(/\D/g, "")}?text=${encodeURIComponent(message)}`, "_blank");
                  }}>Preparar cobrança</button>}
                </span>
                <div className="row-actions">
                  <button aria-label={`Editar ${c.name}`} onClick={() => edit(c)}><Pencil /></button>
                  <button className="danger-action" aria-label={`Excluir ${c.name}`} onClick={() => remove(c)}><Trash2 /></button>
                </div>
              </div>
            );
          })}
        </div>
      ) : (
        <Empty
          icon={<Users />}
          title="Nenhum cliente ainda"
          text="Cadastre manualmente ou crie um pela gravação."
          action={() => setAdding(true)}
        />
      )}
    </>
  );
}
function Finance({ store, update }: { store: Store; update: (f: (s: Store) => Store) => void }) {
  const [period, setPeriod] = useState<"hoje" | "mês" | "tudo">("mês");
  const tx = store.transactions.filter(
    (t) =>
      period === "tudo" ||
      (period === "hoje"
        ? t.date === isoToday()
        : t.date.startsWith(localMonth())),
  );
  const income = tx
      .filter((t) => t.type === "receita")
      .reduce((a, b) => a + b.value, 0),
    expense = tx
      .filter((t) => t.type === "despesa")
      .reduce((a, b) => a + b.value, 0);
  const max = Math.max(income, expense, 1);
  return (
    <>
      <div className="page-title">
        <h1>Financeiro</h1>
        <p>Veja o dinheiro do seu trabalho sem complicação.</p>
      </div>
      <div className="chips">
        {(["hoje", "mês", "tudo"] as const).map((p) => (
          <button
            className={period === p ? "selected" : ""}
            onClick={() => setPeriod(p)}
            key={p}
          >
            {p === "mês" ? "Este mês" : p === "tudo" ? "Todo período" : "Hoje"}
          </button>
        ))}
      </div>
      <div className="finance-hero">
        <small>Lucro no período</small>
        <h2>{money(income - expense)}</h2>
        <div>
          <span>
            Receitas <b>{money(income)}</b>
          </span>
          <span>
            Despesas <b>{money(expense)}</b>
          </span>
        </div>
      </div>
      <div className="chart-card">
        <h3>Visão rápida</h3>
        <div className="bar">
          <span>Entradas</span>
          <i style={{ width: `${(income / max) * 100}%` }} />
          <b>{money(income)}</b>
        </div>
        <div className="bar expense">
          <span>Saídas</span>
          <i style={{ width: `${(expense / max) * 100}%` }} />
          <b>{money(expense)}</b>
        </div>
      </div>
      <div className="section-head">
        <h3>Movimentações</h3>
      </div>
      {tx.length ? (
        <div className="list">
          {tx
            .slice()
            .reverse()
            .map((t) => (
              <div className="transaction" key={t.id}>
                <div className={t.type}>{t.type === "receita" ? "+" : "−"}</div>
                <span>
                  <b>{t.description}</b>
                  <small>
                    {new Date(t.date + "T12:00").toLocaleDateString("pt-BR")}
                  </small>
                </span>
                <strong className={t.type}>
                  {t.type === "receita" ? "+ " : "− "}
                  {money(t.value)}
                </strong>
                <button className="mini-delete" aria-label="Excluir movimentação" onClick={() => {
                  if (!window.confirm("Excluir esta movimentação?")) return;
                  update((s) => ({ ...s, transactions: s.transactions.filter((x) => x.id !== t.id) }));
                }}><Trash2 /></button>
              </div>
            ))}
        </div>
      ) : (
        <Empty
          icon={<Wallet />}
          title="Sem movimentações"
          text="Receitas e despesas aparecerão aqui."
        />
      )}
    </>
  );
}
function Jobs({ store, update }: { store: Store; update: (f: (s: Store) => Store) => void }) {
  const [q, setQ] = useState("");
  const jobs = store.jobs.filter((j) => `${j.clientName} ${j.description} ${j.category} ${j.status} ${j.notes}`.toLowerCase().includes(q.toLowerCase()));
  return (
    <>
      <div className="page-title">
        <h1>Serviços</h1>
        <p>Histórico organizado do seu trabalho.</p>
      </div>
      <div className="search"><Search /><input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Buscar cliente, serviço ou situação" /></div>
      {jobs.length ? (
        <div className="list">
          {jobs
            .slice()
            .reverse()
            .map((j) => (
              <JobRow job={j} key={j.id} onEdit={() => {
                const description = window.prompt("Descrição do serviço", j.description)?.trim();
                if (!description) return;
                const category = window.prompt("Tipo de serviço / profissão", j.category)?.trim();
                if (!category) return;
                update((s) => ({ ...s, jobs: s.jobs.map((job) => job.id === j.id ? { ...job, description, category } : job) }));
              }} onDelete={() => {
                if (!window.confirm(`Excluir o serviço de ${j.clientName}? As movimentações ligadas a ele também serão excluídas.`)) return;
                update((s) => ({
                  ...s,
                  jobs: s.jobs.filter((x) => x.id !== j.id),
                  transactions: s.transactions.filter((x) => x.jobId !== j.id),
                  appointments: s.appointments.filter((x) => x.id !== j.id),
                }));
              }} />
            ))}
        </div>
      ) : (
        <Empty
          icon={<BriefcaseBusiness />}
          title="Nenhum serviço"
          text="Grave seu primeiro serviço para começar."
        />
      )}
    </>
  );
}
function JobRow({ job, onDelete, onEdit }: { job: Job; onDelete?: () => void; onEdit?: () => void }) {
  return (
    <div className="job-row">
      <div className="job-icon">
        <BriefcaseBusiness />
      </div>
      <span>
        <b>{job.clientName}</b>
        <small>
          {job.description} •{" "}
          {new Date(job.date + "T12:00").toLocaleDateString("pt-BR")}
        </small>
        <em>{job.status}</em>
      </span>
      <strong>{money(job.total)}</strong>
      {onEdit && <button className="mini-delete" aria-label="Editar serviço" onClick={onEdit}><Pencil /></button>}
      {onDelete && <button className="mini-delete" aria-label="Excluir serviço" onClick={onDelete}><Trash2 /></button>}
      <details className="saved-report"><summary>Ver relatório completo</summary>
        <p><b>Função:</b> {job.category || "Não informada"}</p>
        <p><b>Serviço:</b> {job.description}</p>
        <p><b>Total:</b> {money(job.total)} · <b>Recebido:</b> {money(job.received)} · <b>Pendente:</b> {money(job.pending)}</p>
        <p><b>Despesas:</b> {money(job.expenses)} · <b>Lucro estimado:</b> {money(job.total - job.expenses)}</p>
        {job.materials.length > 0 && <p><b>Materiais:</b> {job.materials.join("; ")}</p>}
        {job.nextVisit && <p><b>Retorno:</b> {new Date(job.nextVisit + "T12:00").toLocaleDateString("pt-BR")} {job.time || ""}</p>}
        {job.notes && <p className="report-notes"><b>Detalhes e observações:</b>{"\n"}{job.notes}</p>}
      </details>
    </div>
  );
}
function Documents({
  store,
  update,
  notify,
}: {
  store: Store;
  update: (f: (s: Store) => Store) => void;
  notify: (s: string) => void;
}) {
  const [jobId, setJobId] = useState(store.jobs.at(-1)?.id || "");
  const [type, setType] = useState<"orçamento" | "recibo" | "ordem de serviço">("orçamento");
  const job = store.jobs.find((j) => j.id === jobId);
  const share = () => {
    if (!job) return;
    const text =
      type === "orçamento"
        ? `ORÇAMENTO — ${store.prefs.name}\nCliente: ${job.clientName}\nServiço: ${job.description}\nValor total: ${money(job.total)}\nValidade: 15 dias`
        : type === "recibo"
          ? `RECIBO — ${store.prefs.name}\nRecebi de ${job.clientName} o valor de ${money(job.received)}, referente a ${job.description}.\nData: ${new Date(job.date + "T12:00").toLocaleDateString("pt-BR")}\nID: ${job.id.slice(0, 8).toUpperCase()}`
          : `ORDEM DE SERVIÇO — ${store.prefs.name}\nCliente: ${job.clientName}\nServiço: ${job.description}\nData: ${new Date(job.date + "T12:00").toLocaleDateString("pt-BR")}\nSituação: ${job.status}\nValor: ${money(job.total)}\nID: ${job.id.slice(0, 8).toUpperCase()}`;
    window.open(`https://wa.me/?text=${encodeURIComponent(text)}`, "_blank");
    if (type !== "ordem de serviço") update((s) => ({
      ...s,
      usage: {
        ...s.usage,
        [type === "orçamento" ? "budgets" : "receipts"]:
          s.usage[type === "orçamento" ? "budgets" : "receipts"] + 1,
      },
    }));
    notify("Documento preparado para compartilhar");
  };
  return (
    <>
      <div className="page-title">
        <h1>Documentos</h1>
        <p>Orçamentos e recibos profissionais.</p>
      </div>
      <div className="doc-tabs">
        <button
          className={type === "orçamento" ? "selected" : ""}
          onClick={() => setType("orçamento")}
        >
          <FileText /> Orçamento
        </button>
        <button
          className={type === "recibo" ? "selected" : ""}
          onClick={() => setType("recibo")}
        >
          <ReceiptText /> Recibo
        </button>
        <button className={type === "ordem de serviço" ? "selected" : ""} onClick={() => setType("ordem de serviço")}>
          <BriefcaseBusiness /> Ordem de serviço
        </button>
      </div>
      <div className="form-card">
        <label>
          Escolha o serviço
          <select value={jobId} onChange={(e) => setJobId(e.target.value)}>
            <option value="">Selecione…</option>
            {store.jobs.map((j) => (
              <option value={j.id} key={j.id}>
                {j.clientName} — {j.description}
              </option>
            ))}
          </select>
        </label>
        {job && (
          <div className="paper">
            <span>TáAnotado</span>
            <h2>{type.toUpperCase()}</h2>
            <p>
              <b>Profissional</b>
              {store.prefs.name}
            </p>
            <p>
              <b>Cliente</b>
              {job.clientName}
            </p>
            <p>
              <b>Serviço</b>
              {job.description}
            </p>
            <p>
              <b>{type === "recibo" ? "Valor recebido" : "Valor total"}</b>
              {money(type === "recibo" ? job.received : job.total)}
            </p>
            <small>Documento nº {job.id.slice(0, 8).toUpperCase()}</small>
          </div>
        )}
        <button className="primary full" disabled={!job} onClick={share}>
          <MessageCircle /> Compartilhar no WhatsApp
        </button>
        <button
          className="secondary full"
          disabled={!job}
          onClick={() => window.print()}
        >
          <Download /> Imprimir / Salvar PDF
        </button>
      </div>
    </>
  );
}
function Agenda({ store }: { store: Store }) {
  const appointments = [
    ...store.jobs.filter((j) => j.nextVisit || j.status === "agendado")
      .map((j) => ({ id: j.id, clientName: j.clientName, description: j.description,
        date: j.nextVisit || j.date, time: j.time })),
    ...store.appointments.map((a) => ({ ...a })),
  ].sort((a, b) => `${a.date}${a.time || ""}`.localeCompare(`${b.date}${b.time || ""}`));
  return <>
    <div className="page-title"><h1>Agenda</h1><p>Retornos e serviços registrados.</p></div>
    <div className="list">{appointments.length ? appointments.map((job) =>
      <div className="client-row" key={job.id}>
        <CalendarDays /><span><b>{job.clientName} — {job.description}</b>
          <small>{new Date(job.date + "T12:00").toLocaleDateString("pt-BR")}{job.time ? ` às ${job.time}` : ""}</small></span>
      </div>) : <p className="subtle">Nenhum compromisso registrado.</p>}</div>
  </>;
}
function More({
  store,
  update,
  go,
}: {
  store: Store;
  update: (f: (s: Store) => Store) => void;
  go: (p: Page) => void;
}) {
  const usage = store.usage;
  const [audioEntries, setAudioEntries] = useState<AudioEntry[]>([]);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [voiceServer, setVoiceServer] = useState(localStorage.getItem("taanotado-voice-server") || "");
  const [premiumPeriod, setPremiumPeriod] = useState("monthly");
  const [profileName, setProfileName] = useState(store.prefs.name);
  const [profileProfession, setProfileProfession] = useState(store.prefs.profession);
  const importRef = useRef<HTMLInputElement | null>(null);
  useEffect(() => {
    listAudioEntries()
      .then(setAudioEntries)
      .catch(() => setAudioEntries([]));
  }, []);
  return (
    <>
      <div className="page-title">
        <h1>Mais</h1>
        <p>Documentos, plano e configurações.</p>
      </div>
      <div className="profile-card">
        <div className="client-avatar">{store.prefs.name[0]}</div>
        <span>
          <b>{store.prefs.name}</b>
          <small>{store.prefs.profession}</small>
        </span>
        <div className="plan">TESTE GRÁTIS</div>
      </div>
      <div className="menu-list">
        <button onClick={() => go("jobs")}>
          <BriefcaseBusiness />
          <span>
            Todos os serviços<small>Histórico completo</small>
          </span>
          <ChevronRight />
        </button>
        <button onClick={() => go("budgets")}>
          <FileText />
          <span>
            Orçamentos e recibos<small>Gerar e compartilhar</small>
          </span>
          <ChevronRight />
        </button>
        <button onClick={() => go("agenda")}>
          <CalendarDays />
          <span>
            Agenda<small>Próximos retornos</small>
          </span>
          <ChevronRight />
        </button>
        <button onClick={() => {
          const file = new Blob([JSON.stringify({ exportedAt: new Date().toISOString(), data: store }, null, 2)], { type: "application/json" });
          const url = URL.createObjectURL(file);
          const link = document.createElement("a"); link.href = url; link.download = "taanotado-backup.json"; link.click();
          setTimeout(() => URL.revokeObjectURL(url), 1000);
        }}>
          <Download /><span>Exportar meus dados<small>Cópia dos registros deste aparelho</small></span><ChevronRight />
        </button>
        <button onClick={() => importRef.current?.click()}>
          <Upload /><span>Restaurar backup<small>Importar uma cópia do TáAnotado</small></span><ChevronRight />
        </button>
        <input ref={importRef} className="hidden-input" type="file" accept="application/json,.json" onChange={async (event) => {
          const file = event.target.files?.[0];
          event.target.value = "";
          if (!file) return;
          try {
            const parsed = JSON.parse(await file.text());
            const data = parsed?.data ?? parsed;
            if (!data?.prefs || !Array.isArray(data.clients) || !Array.isArray(data.jobs) ||
              !Array.isArray(data.transactions) || !Array.isArray(data.appointments))
              throw new Error("invalid");
            if (!window.confirm("Restaurar este backup? Os dados atuais deste aparelho serão substituídos.")) return;
            update(() => ({
              ...emptyStore,
              ...data,
              prefs: { ...emptyStore.prefs, ...data.prefs, onboarded: true },
              usage: { ...emptyStore.usage, ...(data.usage || {}) },
              auditEvents: Array.isArray(data.auditEvents) ? data.auditEvents : [],
            }));
            alert("Backup restaurado com sucesso.");
          } catch {
            alert("Este arquivo não é um backup válido do TáAnotado.");
          }
        }} />
        <button onClick={() => {
          const cell = (value: unknown) => {
            const s = String(value ?? "");
            const safe = /^[=+\-@\t\r]/.test(s) ? `'${s}` : s;
            return `"${safe.replace(/"/g, '""')}"`;
          };
          const rows = [["data", "tipo", "descrição", "valor", "forma de pagamento"],
            ...store.transactions.map((t) => [t.date, t.type, t.description, String(t.value), t.paymentMethod || ""])]
            .map((row) => row.map(cell).join(";")).join("\r\n");
          const url = URL.createObjectURL(new Blob(["\uFEFF" + rows], { type: "text/csv;charset=utf-8" }));
          const link = document.createElement("a"); link.href = url; link.download = "taanotado-financeiro.csv"; link.click();
          setTimeout(() => URL.revokeObjectURL(url), 1000);
        }}>
          <Download /><span>Exportar financeiro<small>Planilha CSV dos registros</small></span><ChevronRight />
        </button>
        <button onClick={() => setSettingsOpen(true)}>
          <Settings />
          <span>
            Configurações<small>Perfil e preferências</small>
          </span>
          <ChevronRight />
        </button>
      </div>
      {settingsOpen && <div className="modal"><div>
        <button className="close" onClick={() => setSettingsOpen(false)}><X /></button>
        <h2>Configurações</h2>
        <p className="modal-copy">Atualize os dados que aparecem nos documentos.</p>
        <Field label="Endereço do serviço de voz (HTTPS)" value={voiceServer} onChange={setVoiceServer} />
        <Field label="Seu nome" value={profileName} onChange={setProfileName} />
        <label>Profissão / tipo de trabalho<select value={professions.includes(profileProfession) ? profileProfession : "Outro"} onChange={(e) => setProfileProfession(e.target.value)}>
          {professions.map((p) => <option key={p}>{p}</option>)}
        </select></label>
        <Field label="Profissão personalizada (pode alterar quando quiser)" value={profileProfession} onChange={setProfileProfession} />
        <p className="subtle">Trocar sua profissão não altera seus serviços anteriores. Cada novo serviço pode ter uma descrição diferente.</p>
        <button className="primary full" onClick={() => {
          if (!profileName.trim()) return alert("Informe seu nome.");
          if (voiceServer.trim()) {
            try { const url = new URL(voiceServer.trim()); if (url.protocol !== "https:" || url.username || url.password || url.pathname !== "/" || url.search || url.hash) throw new Error(); }
            catch { return alert("Informe apenas o endereço HTTPS do serviço, sem caminho, senha ou chave de API."); }
          }
          localStorage.setItem("taanotado-voice-server", voiceServer.trim());
          update((s) => ({ ...s, prefs: { ...s.prefs, name: profileName.trim(), profession: profileProfession } }));
          setSettingsOpen(false);
        }}>Salvar configurações</button>
      </div></div>}
      <div className="usage-card">
        <div>
          <Crown />
          <span>
            <b>Teste gratuito — todas as funções liberadas</b>
            <small>Uso neste mês</small>
          </span>
        </div>
        <Usage
          label="Gravações"
          value={usage.recordings}
          max={null}
        />
        <Usage
          label="Minutos de áudio"
          value={usage.minutes}
          max={null}
        />
        <h3>Premium</h3>
        <div className="premium-options">
          <button aria-pressed={premiumPeriod === "monthly"} onClick={() => setPremiumPeriod("monthly")}><b>Mensal</b><small>1 mês de acesso · preço a definir</small></button>
          <button aria-pressed={premiumPeriod === "quarterly"} onClick={() => setPremiumPeriod("quarterly")}><b>3 meses</b><small>3 meses de acesso · preço a definir</small></button>
        </div>
        <p>Durante o teste de 14 dias, áudio e todas as outras funções são gratuitos. Após encerrarmos o teste, a assinatura será necessária para organizar por áudio. Digitação e organização manual continuarão gratuitas.</p>
        <button className="primary full" disabled>Áudio grátis durante os testes</button>
        <p className="subtle">Período escolhido: {premiumPeriod === "monthly" ? "mensal" : "3 meses"}. A cobrança será liberada após a configuração dos preços e do pagamento.</p>
      </div>
      <div className="usage-card">
        <div>
          <Mic />
          <span>
            <b>Áudios / Entradas</b>
            <small>Relatos preservados neste aparelho</small>
          </span>
        </div>
        {audioEntries.length ? (
          audioEntries.slice(0, 3).map((entry) => (
            <div className="audio-entry" key={entry.id}>
              <span>{new Date(entry.createdAt).toLocaleString("pt-BR")}</span>
              <b>
                {entry.status === "received"
                  ? "Recebido"
                  : entry.status.replace("_", " ")}
              </b>
            </div>
          ))
        ) : (
          <p className="subtle">Nenhum áudio pendente.</p>
        )}
      </div>
      <div className="security-note">
        <ShieldCheck />
        <span>
          <b>Privacidade por padrão</b>Sem leitura de outros apps, sem overlay e
          sem gravação escondida.
        </span>
      </div>
    </>
  );
}
function Usage({
  label,
  value,
  max,
}: {
  label: string;
  value: number;
  max: number | null;
}) {
  return (
    <div className="usage">
      <span>
        {label}
        <b>
          {value}{max == null ? " · sem limite de plano no teste" : ` de ${max}`}
        </b>
      </span>
      <i>
        <em style={{ width: `${Math.min(100, (max == null ? 0 : value / max * 100))}%` }} />
      </i>
    </div>
  );
}
function Empty({
  icon,
  title,
  text,
  action,
}: {
  icon: React.ReactNode;
  title: string;
  text: string;
  action?: () => void;
}) {
  return (
    <div className="empty">
      {icon}
      <b>{title}</b>
      <p>{text}</p>
      {action && <button onClick={action}>Começar agora</button>}
    </div>
  );
}
function Nav({ page, go }: { page: Page; go: (p: Page) => void }) {
  const items: [Page, string, React.ReactNode][] = [
    ["home", "Início", <Home />],
    ["clients", "Clientes", <Users />],
    ["record", "Organizar", <Mic />],
    ["finance", "Financeiro", <Wallet />],
    ["more", "Mais", <Menu />],
  ];
  return (
    <nav>
      {items.map(([p, l, i]) => (
        <button
          key={p}
          onClick={() => go(p)}
          className={`${page === p ? "active" : ""} ${p === "record" ? "record-nav" : ""}`}
        >
          {i}
          <span>{l}</span>
        </button>
      ))}
    </nav>
  );
}
createRoot(document.getElementById("root")!).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>,
);
