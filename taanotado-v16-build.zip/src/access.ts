// Test period is controlled by the owner, not by a device clock.
// After the 14-day test, enable server-enforced paid audio in a future release.
export const ACCESS_POLICY = { phase: "testing", testDays: 14, audioPaymentRequired: false } as const;
export function canUseAudio(entitlement: { active: boolean; verifiedByServer: boolean }): boolean {
  return !ACCESS_POLICY.audioPaymentRequired || (entitlement.active && entitlement.verifiedByServer);
}
