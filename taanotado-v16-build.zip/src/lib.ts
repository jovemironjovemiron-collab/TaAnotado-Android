import type { Draft, Job, Client, Transaction, Appointment, AuditEvent, UserPrefs, Usage } from "./types";
import { interpretPortuguese } from "./voice/interpreter";

export const money = (n: number) =>
  new Intl.NumberFormat("pt-BR", { style: "currency", currency: "BRL" }).format(n || 0);
export const isoToday = (date = new Date()) => {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, "0");
  const day = String(date.getDate()).padStart(2, "0");
  return `${year}-${month}-${day}`;
};
export const localMonth = (date = new Date()) => isoToday(date).slice(0, 7);
export const id = () => crypto.randomUUID?.() || `${Date.now()}-${Math.random()}`;

export function interpretSpeech(input: string): Draft {
  const result = interpretPortuguese(input);
  const confidence = (level: string): "alta" | "média" | "baixa" =>
    level === "high" ? "alta" : level === "medium" ? "média" : "baixa";
  const pending = result.financial.pending.value;
  const total = result.financial.total.value;
  const received = result.financial.received.value;
  return {
    client: result.client.value,
    service: result.service.value,
    total,
    received,
    pending,
    expenses: result.expenses.map((x) => x.value),
    date: isoToday(),
    nextVisit: result.schedule[0]?.date || null,
    nextVisitTime: result.schedule[0]?.time || null,
    status:
      pending != null && pending > 0
        ? result.schedule.length ? "em andamento" : "aguardando pagamento"
        : total != null && received === total
          ? "pago"
          : result.schedule.length ? "em andamento" : "concluído",
    materials: result.materials.map((x) =>
      x.unit && x.description
        ? `${x.quantity ?? ""} ${x.unit} de ${x.description}`.trim()
        : [x.quantity, x.unit, x.description].filter(Boolean).join(" "),
    ),
    notes: result.originalTranscript,
    confidence: {
      cliente: confidence(result.client.confidence),
      valores: confidence(result.financial.total.confidence),
      data: result.schedule.length ? "média" : "baixa",
    },
    warnings: result.warnings,
  };
}

const KEY = "organizae-v1";
export interface Store {
  prefs: UserPrefs;
  clients: Client[];
  jobs: Job[];
  transactions: Transaction[];
  appointments: Appointment[];
  auditEvents: AuditEvent[];
  usage: Usage;
}
export const emptyStore: Store = {
  prefs: { profession: "", name: "", plan: "FREE", onboarded: false },
  clients: [],
  jobs: [],
  transactions: [],
  appointments: [],
  auditEvents: [],
  usage: {
    month: localMonth(),
    recordings: 0,
    minutes: 0,
    aiCalls: 0,
    budgets: 0,
    receipts: 0,
  },
};
export const load = (): Store => {
  try {
    const parsed = JSON.parse(localStorage.getItem(KEY) || "{}");
    return {
      ...emptyStore,
      ...parsed,
      prefs: { ...emptyStore.prefs, ...(parsed.prefs || {}) },
      usage: { ...emptyStore.usage, ...(parsed.usage || {}) },
      clients: Array.isArray(parsed.clients) ? parsed.clients : [],
      jobs: Array.isArray(parsed.jobs) ? parsed.jobs : [],
      transactions: Array.isArray(parsed.transactions) ? parsed.transactions : [],
      appointments: Array.isArray(parsed.appointments) ? parsed.appointments : [],
      auditEvents: Array.isArray(parsed.auditEvents) ? parsed.auditEvents : [],
    };
  } catch {
    return emptyStore;
  }
};
export const save = (s: Store) => localStorage.setItem(KEY, JSON.stringify(s));
export const FREE_LIMITS = {
  clients: 15,
  recordings: 10,
  minutes: 20,
  budgets: 3,
  receipts: 5,
};
