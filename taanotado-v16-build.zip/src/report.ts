import type { Draft, Status } from "./types";
export interface WorkReport {
  client: string; phone: string; address: string; profession: string; service: string;
  date: string; total: string; received: string; expense: string; materials: string;
  email: string; reference: string; paymentMethod: string; paymentDue: string; deadline: string;
  startTime: string; endTime: string; tasks: string; warranty: string; budgetValidity: string;
  nextVisit: string; nextVisitTime: string; status: Status; notes: string;
}
export function organizeReport(report: WorkReport): Draft {
  const amount = (raw: string, label: string, fallback: number | null): number | null => {
    if (!raw.trim()) return fallback;
    const value = Number(raw.trim().replace(/\s/g, "").replace(",", "."));
    if (!Number.isFinite(value) || value < 0) throw new Error(`Confira o campo ${label}. Use um valor positivo ou zero, como 150,50.`);
    return value;
  };
  if (!report.client.trim() || !report.service.trim()) throw new Error("Preencha nome do cliente e o que você fez.");
  const total = amount(report.total, "valor total", null);
  if (total == null) throw new Error("Preencha o valor total. Informe 0 se o serviço foi gratuito.");
  const received = amount(report.received, "valor recebido", 0)!;
  const expense = amount(report.expense, "despesas", 0)!;
  if (received > total) throw new Error("O valor recebido não pode superar o valor total.");
  if (report.nextVisitTime && !report.nextVisit) throw new Error("Informe a data do retorno para usar o horário.");
  if (report.status === "pago" && received !== total) throw new Error("Para marcar como pago, o recebido deve ser igual ao total.");
  const details = [
    ["E-mail do cliente", report.email], ["Referência / identificação do trabalho", report.reference],
    ["Forma de pagamento", report.paymentMethod], ["Data combinada para pagamento", report.paymentDue],
    ["Prazo de entrega", report.deadline], ["Horário de início", report.startTime], ["Horário de término", report.endTime],
    ["Tarefas e pendências", report.tasks], ["Garantia / condições", report.warranty],
    ["Validade do orçamento", report.budgetValidity], ["Observações", report.notes],
  ].filter(([, value]) => value.trim()).map(([label, value]) => `${label}: ${value.trim()}`).join("\n");
  return { client: report.client.trim(), service: report.service.trim(), category: report.profession.trim(),
    phone: report.phone.trim(), address: report.address.trim(), total, received, pending: total - received,
    expenses: [expense], date: report.date || null, nextVisit: report.nextVisit || null,
    nextVisitTime: report.nextVisitTime || null, status: report.status,
    materials: report.materials.split(/\n/).map((item) => item.trim()).filter(Boolean),
    notes: details, paymentMethod: report.paymentMethod.trim() || undefined, confidence: { cliente: "alta", valores: "alta", data: "alta" }, warnings: [] };
}
