import { describe, expect, it } from "vitest";
import { interpretSpeech } from "./lib";
describe("interpretador de fala", () => {
  it("identifica serviço pago integralmente", () => {
    const d = interpretSpeech(
      "Fiz um serviço para João por 300 reais e ele pagou tudo.",
    );
    expect(d.client).toBe("Joao");
    expect(d.total).toBe(300);
    expect(d.received).toBe(300);
    expect(d.pending).toBe(0);
  });
  it("identifica pagamento parcial", () => {
    const d = interpretSpeech("Carlos me pagou 200 dos 500.");
    expect(d.received).toBe(200);
    expect(d.total).toBe(500);
    expect(d.pending).toBe(300);
  });
  it("identifica despesa", () =>
    expect(
      interpretSpeech("Gastei 80 de material no serviço de Maria.").expenses,
    ).toEqual([80]));
  it("interpreta retorno amanhã", () =>
    expect(
      interpretSpeech("Amanhã vou voltar na casa do Pedro.").nextVisit,
    ).toBeTruthy());
  it("calcula pintura", () => {
    const d = interpretSpeech(
      "Serviço de pintura 1200, gastei 350, recebi 600.",
    );
    expect(d.total).toBe(1200);
    expect(d.expenses).toEqual([350]);
    expect(d.received).toBe(600);
    expect(d.pending).toBe(600);
  });
  it("identifica dívida explícita", () =>
    expect(interpretSpeech("José ficou devendo 150.").pending).toBe(150));
  it("não inventa nome", () =>
    expect(interpretSpeech("Recebi mais 100 hoje.").client).toBeNull());
  it("avisa valores inconsistentes", () =>
    expect(
      interpretSpeech(
        "Cobrei 500, recebi 300 e ficou devendo 250",
      ).warnings.some((x) => x.includes("não fecham")),
    ).toBe(true));
  it("aceita fala vazia sem quebrar", () =>
    expect(interpretSpeech("").warnings.length).toBeGreaterThan(0));
  it("extrai material solicitado", () =>
    expect(
      interpretSpeech("Preciso comprar dois metros de cabo.").materials,
    ).toContain("2 metros de cabo"));
  it("não inventa material ausente", () =>
    expect(interpretSpeech("Carlos pagou 100 hoje.").materials).toEqual([]));
});
