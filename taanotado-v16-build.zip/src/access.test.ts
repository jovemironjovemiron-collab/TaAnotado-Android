import { describe, it, expect } from "vitest";
import { ACCESS_POLICY, canUseAudio } from "./access";
describe("teste gratuito", () => {
  it("libera áudio sem assinatura durante a fase de teste", () => {
    expect(ACCESS_POLICY.testDays).toBe(14);
    expect(canUseAudio({ active: false, verifiedByServer: false })).toBe(true);
  });
});
