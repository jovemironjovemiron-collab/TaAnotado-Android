import { describe, expect, it } from "vitest";
import { organizeReport, type WorkReport } from "./report";
const report: WorkReport = { client: "João", phone: "82999999999", address: "Rua A", profession: "Pintor", service: "Pintura da sala", date: "2026-10-04", total: "450,50", received: "100", expense: "90,50", materials: "Tinta, 2 latas\nRolo", nextVisit: "", nextVisitTime: "", status: "em andamento", notes: "Proteger os móveis", email: "joao@example.test", reference: "OS 1", paymentMethod: "Pix", paymentDue: "2026-10-10", deadline: "2026-10-09", startTime: "08:00", endTime: "17:00", tasks: "Pintar a porta", warranty: "30 dias", budgetValidity: "2026-10-07" };
describe("relatório digitado", () => {
  it("preserva dados e calcula saldo sem interpretar nomes ou descrição", () => {
    const draft = organizeReport(report);
    expect(draft.pending).toBe(350.5);
    expect(draft.service).toBe(report.service);
    expect(draft.category).toBe("Pintor");
    expect(draft.materials).toEqual(["Tinta, 2 latas", "Rolo"]);
    expect(draft.phone).toBe(report.phone);
    for (const key of ["email", "reference", "paymentDue", "deadline", "tasks", "warranty", "budgetValidity", "startTime", "endTime"] as const) expect(draft.notes).toContain(report[key]);
    expect(draft.paymentMethod).toBe("Pix");
  });
  it("não cria valor total nem aceita recebido acima do combinado", () => {
    expect(() => organizeReport({ ...report, total: "" })).toThrow("valor total");
    expect(() => organizeReport({ ...report, received: "900" })).toThrow("superar");
    expect(() => organizeReport({ ...report, total: "-1" })).toThrow("Confira");
  });
  it("permite serviço gratuito e identifica campos opcionais vazios", () => {
    expect(organizeReport({ ...report, total: "0", received: "", expense: "" }).pending).toBe(0);
    expect(() => organizeReport({ ...report, nextVisitTime: "09:00" })).toThrow("data do retorno");
  });
});
