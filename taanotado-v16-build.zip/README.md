# TáAnotado — versão Android de teste

Este é o projeto existente, derivado da versão 8 implantada no Site. O APK Android usa a URL existente do TáAnotado, mantendo o Worker e `OPENAI_API_KEY` apenas no servidor. O acesso ao Site requer login na conta autorizada; a compatibilidade dessa autenticação e da gravação no WebView Android ainda depende de teste no celular.

## Android Studio

Abra a pasta `android/` deste pacote no Android Studio. Use JDK 17 e instale Android SDK Platform 35 e SDK Build-Tools 35.x. O Gradle Wrapper 8.11.1 e o Android Gradle Plugin 8.7.2 estão definidos no projeto; o Android Studio baixa as dependências durante a sincronização. Conexão à internet é necessária para esta etapa e para o áudio/IA.

Configuração: compileSdk 35, targetSdk 35, minSdk 23, applicationId `com.organizae.app`, versionName `1.0`, versionCode 1. O nome mostrado ao usuário é TáAnotado. O pacote inclui assets web já sincronizados e as permissões `INTERNET` e `RECORD_AUDIO`.

Em Android Studio, use **Build > Build Bundle(s) / APK(s) > Build APK(s)**. O arquivo de teste será criado em `android/app/build/outputs/apk/debug/app-debug.apk`.

Para refazer os assets após editar o web app, rode `npm ci` e `npm run android:sync` na raiz antes de gerar outro APK. Isso cria somente os assets de navegador em `android/app/src/main/assets/public`; `dist/server` e `worker` não são copiados para o APK. Testes existentes: `npm test` (110 aprovados). Para linha de comando, rode `cd android && ./gradlew assembleDebug` (Windows: `gradlew.bat assembleDebug`).

A versão de teste depende do Site implantado e exige internet para entrar e usar transcrição/IA. A chave da OpenAI não está neste pacote; configure-a apenas como segredo do Site. O áudio real com login no Android ainda precisa de verificação em aparelho.
