# TáAnotado v14

Continua da v13. Todas as funções liberadas, sem limite comercial de gravações durante os testes. Limites técnicos de duração/tamanho por áudio preservados. Teste planejado de 14 dias; nenhuma data de início nem cobrança automática foi presumida. O proprietário encerra a fase de testes em uma futura implantação. Áudio pago depois do encerramento, texto e operação manual permanecem gratuitos. ACCESS_POLICY prepara a decisão, mas cobrança e autorização paga ainda precisam ser implementadas no servidor; nenhuma preferência local deve ativar assinatura paga.

Profissão selecionável e personalizada em Mais > Configurações. Pode trocar a qualquer momento. Serviços antigos preservados. Cada serviço pode ter sua descrição e tipo alterados no botão Editar da lista Serviços; cancelar não modifica registros.

Agente: instruções ampliadas para português coloquial, profissões variadas, pagamentos/despesas/materiais/compromissos, autocorreções e ausência de dados. Contexto com profissão e data atual enviado como dado. Valores por extenso validados com o normalizador português existente. Confirmação humana continua obrigatória. Relatos de múltiplos clientes/serviços pedem separação, evitando salvar tudo em um único registro. Não há garantia de entender qualquer fala, nem suporte automático a todo comando possível. Texto original preservado. Servidor independente e teste real de voz continuam pendentes conforme ENTREGA-V13.md.

Validação: testes existentes mais testes de valores por extenso e liberação gratuita. APK não gerado neste ambiente, devido a download Gradle bloqueado e SDK não configurado. Workflow GitHub atualizado para v14; pacote original preservado.
