import { mkdirSync, readFileSync, readdirSync, writeFileSync, copyFileSync } from "node:fs";
import path from "node:path";

const root = path.resolve("dist");
const files = {};
function collect(directory, prefix = "") {
  for (const entry of readdirSync(directory, { withFileTypes: true })) {
    if (entry.name === "server" || entry.name === ".openai") continue;
    const relative = `${prefix}/${entry.name}`;
    if (entry.isDirectory()) collect(path.join(directory, entry.name), relative);
    else if (entry.isFile()) files[relative] = readFileSync(path.join(directory, entry.name)).toString("base64");
  }
}
collect(root);
mkdirSync(path.join(root, "server"), { recursive: true });
copyFileSync("worker/voice-api.mjs", path.join(root, "server/voice-api.mjs"));
copyFileSync("worker/normalizer.mjs", path.join(root, "server/normalizer.mjs"));
writeFileSync(path.join(root, "server/index.js"), `import { handleVoiceRequest } from "./voice-api.mjs";
const assets = ${JSON.stringify(files)};
const mime = { html: "text/html; charset=utf-8", js: "text/javascript; charset=utf-8",
  css: "text/css; charset=utf-8", svg: "image/svg+xml", png: "image/png" };
export default { async fetch(request, env) {
  const path = new URL(request.url).pathname;
  if (path === "/api/voice/process") return handleVoiceRequest(request, env);
  if (request.method !== "GET" && request.method !== "HEAD") return new Response("Method Not Allowed", { status: 405 });
  const key = Object.hasOwn(assets, path) ? path : (path === "/" ? "/index.html" : null);
  if (!key) return new Response("Not Found", { status: 404 });
  const extension = key.split(".").pop();
  const data = Uint8Array.from(atob(assets[key]), char => char.charCodeAt(0));
  return new Response(request.method === "HEAD" ? null : data, { headers: {
    "content-type": mime[extension] || "application/octet-stream",
    "x-content-type-options": "nosniff", "cache-control": key === "/index.html" ? "no-cache" : "public, max-age=31536000, immutable",
  } });
} };\n`);
