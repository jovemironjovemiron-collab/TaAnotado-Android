import { cpSync, mkdirSync, rmSync } from "node:fs";

// Capacitor receives only the browser assets; the Worker and its server-only
// source must never be copied into the Android application package.
rmSync("dist-android", { recursive: true, force: true });
mkdirSync("dist-android", { recursive: true });
cpSync("dist/index.html", "dist-android/index.html");
cpSync("dist/assets", "dist-android/assets", { recursive: true });
cpSync("dist/favicon.svg", "dist-android/favicon.svg");

