# Auditoria e evolução do sistema de voz — Organizaê

Data: 25/09/2026  
Estado: implementação local validada; nenhuma publicação realizada.

## 1. O que existia

A base já possuía gravação explícita pelo usuário, pausa/continuação, contador, reprodução, regravação, entrada por texto, parser inicial, validação financeira simples, conferência editável, persistência local, clientes, serviços, financeiro e documentos.

Pontos fracos identificados:

- captura, interpretação e regra de negócio estavam próximas demais;
- parser aceitava principalmente números escritos em algarismos;
- não havia contrato estruturado completo para uma IA externa;
- não havia interfaces para trocar transcrição ou modelo;
- contexto, correção, desfazer e consultas não tinham intenções próprias;
- áudio ainda não tinha uma caixa local persistente;
- conflitos não carregavam valor esperado e informado;
- faltavam fingerprint, plano de ações e testes amplos;
- identificador Android antigo ainda permanecia em arquivos nativos.

## 2. Referências pesquisadas

- Google Cloud Speech-to-Text: confidence por palavra, pontuação automática, streaming e adaptação de vocabulário.
- Android MediaRecorder e áudio: máquina de estados, interrupções, foco de áudio e restrições de microfone em segundo plano.
- Salesforce Einstein Conversation Insights: transcrição separada da gravação, insights, itens de ação, integração com CRM e responsabilidade de consentimento.
- Otter: áudio, transcrição pesquisável, resumo e extração de itens de ação.
- Fireflies: transcrição, notas, tarefas e preenchimento assistido do CRM.

Os conceitos aproveitados foram separação de responsabilidades, estados explícitos, rastreabilidade entre áudio e ações, confiança por informação, confirmação humana e ações propostas. Nenhum código, texto, marca ou interface foi copiado.

## 3. Arquitetura final desta etapa

```text
Captura explícita
  ↓
Caixa local de áudio (IndexedDB)
  ↓
SpeechToTextProvider
  ↓
Transcrição original
  ↓
Normalização pt-BR (sem apagar o original)
  ↓
LanguageUnderstandingProvider
  ↓
StructuredVoiceResult v1
  ↓
DeterministicValidator
  ↓
SafeActionPlanner
  ↓
Conferência humana obrigatória
  ↓
OrganizaeRepository.executeConfirmed
  ↓
Auditoria e registros relacionados
```

Interfaces criadas:

- `SpeechToTextProvider`
- `LanguageUnderstandingProvider`
- `StructuredDataValidator`
- `ActionPlanner`
- `OrganizaeRepository`

## 4. Interpretação

O contrato estruturado contém:

- versão do esquema;
- intenção;
- transcrição original e normalizada;
- cliente e serviço com confiança e evidência;
- total, recebido, pendente e lucro estimado;
- despesas, pagamentos, materiais, tarefas e agenda;
- notas, avisos, informações ausentes e conflitos;
- ações propostas;
- fingerprint determinístico.

A normalização reconhece números comuns em português brasileiro, incluindo “quatrocentos e cinquenta”, “noventa”, “duas” e “dois”. “Conto” é normalizado como reais, mantendo a fala original separada.

## 5. Prevenção de erros

- A IA/provedor apenas propõe dados e ações.
- Toda ação gerada possui `requiresConfirmation: true`.
- O validador recalcula `total - recebido` e não corrige silenciosamente.
- O conflito informa saldo falado e saldo calculado.
- Campos ausentes permanecem nulos e são listados em `missingInformation`.
- Correção e desfazer têm intenções próprias.
- Desfazer gera pedido de confirmação, nunca exclusão direta.
- Fingerprint combina fala normalizada e serviço para detectar repetição.
- O repository só possui método de execução explicitamente confirmada.

## 6. Robustez da captura

- bloqueio contra início duplo;
- pausa e retomada;
- pausa automática ao perder visibilidade;
- tratamento de erro do MediaRecorder;
- encerramento das trilhas do microfone;
- áudio gravado persistido localmente na caixa de entradas;
- fallback de marcação local quando IndexedDB falha;
- mensagem clara quando permissão do microfone falha.

No Android nativo de produção ainda será necessário um plugin de gravação próprio para tratar AudioFocus, interrupção telefônica e foreground service conforme a versão do sistema.

## 7. Arquivos criados

- `src/voice/contracts.ts`
- `src/voice/normalizer.ts`
- `src/voice/dateResolver.ts`
- `src/voice/interpreter.ts`
- `src/voice/validator.ts`
- `src/voice/actionPlanner.ts`
- `src/voice/pipeline.ts`
- `src/voice/audioInbox.ts`
- `src/voice/interpreter.scenarios.test.ts`
- `src/voice/pipeline.test.ts`
- `docs/AUDITORIA-VOZ-ORGANIZAE-25-09-2026.md`
- `android/app/src/main/java/com/organizae/app/MainActivity.java`

## 8. Arquivos alterados

- `src/lib.ts`
- `src/main.tsx`
- `src/style.css`
- `android/app/build.gradle`
- `android/app/src/main/res/values/strings.xml`
- `docs/ARQUITETURA-E-ENTREGA.md`

## 9. Testes e build

- 83 testes automatizados aprovados em 3 arquivos.
- Mais de 50 cenários do interpretador em português brasileiro.
- Pipeline testado com sucesso, indisponibilidade de rede e garantia de confirmação.
- TypeScript e build Vite aprovados.
- Capacitor Android sincronizado.
- Nenhuma publicação feita.

## 10. Dependências externas pendentes

- provedor real de transcrição pt-BR;
- backend autenticado para IA com structured output;
- Firebase Auth, Firestore, Storage e App Check;
- Remote Config para limites e escolha de fornecedor;
- fila backend para áudios grandes e retentativas;
- regras de retenção/exclusão de áudio;
- métricas e custos sem conteúdo sensível;
- plugin Android nativo de gravação e AudioFocus;
- notificações e sincronização multidispositivo.

## 11. Para produção

Antes de produção ainda são necessários testes com áudio real em aparelhos baratos e intermediários, sotaques de várias regiões, ruído de obra e trânsito, consentimento/LGPD, testes de regras Firestore, observabilidade, limite de tamanho/duração, rate limit, exclusão de conta, assinatura de release e revisão da política da Google Play.
