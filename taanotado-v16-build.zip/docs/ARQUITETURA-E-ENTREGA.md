# Organizaê — arquitetura e relatório da versão 0.2.0

## Visão do produto

O Organizaê transforma um relato falado em um rascunho estruturado, exige conferência humana e só então cria cliente, serviço e movimentações. O princípio de segurança é: **a IA sugere; o usuário confirma; o aplicativo salva**.

## Arquitetura

```text
React/Vite (interface)
  ├─ Capacitor Android (empacotamento nativo)
  ├─ armazenamento local (MVP offline)
  ├─ Firebase Auth + Firestore (próxima integração)
  └─ Backend autenticado (próxima integração)
       ├─ transcrição de áudio
       ├─ interpretação em JSON
       ├─ validação de esquema
       └─ medição, limites e custo
```

Nenhuma chave secreta deve entrar no aplicativo. O backend deverá validar o token Firebase, plano, limite mensal, tamanho e duração do áudio antes de chamar qualquer serviço externo.

## Telas implementadas

1. Boas-vindas, nome e profissão.
2. Início com resumo diário, valores pendentes, serviços e atalhos.
3. Gravar com indicação visual, contador, interrupção, reprodução/regravação e revisão do texto.
4. Conferência editável de cliente, serviço, quatro valores, datas, status e observações.
5. Clientes com busca, cadastro e visão de pendência.
6. Serviços com histórico e status.
7. Financeiro com filtros, cartões, gráfico simples e movimentações.
8. Orçamento e recibo com visualização, impressão/PDF e WhatsApp.
9. Mais com plano, consumo mensal, privacidade e atalhos.

## Modelo de dados de produção

Cada usuário é o pai dos próprios dados para simplificar regras e consultas:

```text
users/{uid}
  profile/main
  clients/{clientId}
  services/{serviceId}
  transactions/{transactionId}
  budgets/{budgetId}
  receipts/{receiptId}
  appointments/{appointmentId}
  audioRecords/{audioId}
  subscriptions/current
  usage/{YYYY-MM}
```

Campos financeiros são números em centavos no backend de produção. Registros relevantes usam `createdAt`, `updatedAt`, `ownerUid` e exclusão lógica. As regras fornecidas negam tudo por padrão e só liberam subcoleções do próprio UID.

## Fluxo de áudio e IA

1. O microfone inicia apenas após toque explícito.
2. O usuário interrompe e pode ouvir, apagar ou regravar.
3. O aplicativo mantém o áudio local se a rede falhar.
4. O backend recebe áudio, token e identificador idempotente.
5. Limite e plano são validados antes da transcrição.
6. A transcrição é enviada ao interpretador com esquema fixo.
7. A resposta passa por validação de tipos e regras aritméticas.
8. O usuário vê todos os campos e alertas.
9. Somente a confirmação grava dados definitivos.

O MVP entregue usa um interpretador local determinístico para permitir demonstração sem chave. Ele não finge ser a IA final e não envia áudio para terceiros.

## Validações

- `valor total − recebido = pendente` gera alerta quando não fecha.
- Campos ausentes ficam vazios/nulos; nomes e serviços não são inventados.
- Gravação vazia, ausência de valores e cliente não identificado são sinalizados.
- Receitas e despesas só nascem depois da tela de conferência.
- WhatsApp só abre após ação explícita e a mensagem pode ser revisada.

## Planos configuráveis

| Recurso | Grátis no MVP | Premium de referência |
|---|---:|---:|
| Clientes | 15 | ampliado/ilimitado |
| Gravações/mês | 10 | 100 |
| Minutos/mês | 20 | 300 |
| Orçamentos/mês | 3 | ampliado |
| Recibos/mês | 5 | ampliado |

Os números ficam centralizados em `FREE_LIMITS`; preço não foi fixado. A produção deve obter preço e limites de configuração remota versionada, preparando teste A/B.

## Segurança e privacidade

- Sem AccessibilityService, overlay, OCR de terceiros ou NotificationListener.
- Sem leitura do WhatsApp ou de outro aplicativo.
- Sem chave de IA no cliente.
- Microfone acionado e indicado visualmente.
- Firestore isolado por UID e negação padrão.
- O backend ainda deve adicionar App Check, rate limit, tamanho máximo, antivírus de anexos, logs sem conteúdo sensível e política de retenção/apagamento de áudio.

## Testes e build

- 9 testes automatizados passaram cobrindo pagamento integral, parcial, despesas, data relativa, pintura, dívida explícita, falta de nome, inconsistência e fala vazia.
- `npm run build` concluído com sucesso.
- Projeto Android Capacitor criado e sincronizado.
- APK não foi concluído neste ambiente porque o Gradle 8.11.1 não pôde ser baixado por restrição de rede. Com Android SDK e rede normal: `npm run android:apk`.

## Funciona agora

- Navegação mobile e onboarding.
- Gravação local quando o navegador/Android concede microfone.
- Reprodução, regravação e conferência.
- Interpretação local dos exemplos principais.
- Persistência offline local.
- Clientes, serviços, receitas, despesas, pendências, uso e plano.
- Documento imprimível/salvável como PDF e compartilhamento via WhatsApp.

## Depende de configuração antes de publicar

- Projeto Firebase e login por e-mail/Google.
- Backend real de transcrição e IA.
- Storage e política de retenção de áudio/anexos.
- Pagamento da assinatura Premium e webhook.
- Configuração remota dos planos/preços.
- App Check, observabilidade, política de privacidade e exclusão de conta.
- Ícone final, nome comercial validado, assinatura de produção e testes em aparelhos.

Esta versão não foi publicada na Play Store.
