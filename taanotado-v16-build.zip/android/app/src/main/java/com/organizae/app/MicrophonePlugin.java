package com.organizae.app;
import android.Manifest;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.PermissionState;
import com.getcapacitor.annotation.CapacitorPlugin;
import com.getcapacitor.annotation.Permission;
import com.getcapacitor.annotation.PermissionCallback;
@CapacitorPlugin(name = "Microphone", permissions = {@Permission(alias = "microphone", strings = {Manifest.permission.RECORD_AUDIO})})
public class MicrophonePlugin extends Plugin {
  @PluginMethod public void ensurePermission(PluginCall call) {
    if (getPermissionState("microphone") == PermissionState.GRANTED) call.resolve();
    else requestPermissionForAlias("microphone", call, "permissionResult");
  }
  @PermissionCallback private void permissionResult(PluginCall call) {
    if (getPermissionState("microphone") == PermissionState.GRANTED) call.resolve();
    else call.reject("Permissão de microfone negada. Ative em Configurações > Apps > TáAnotado > Permissões.");
  }
}
