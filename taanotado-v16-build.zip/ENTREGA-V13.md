# TáAnotado v13 — alterações e pendências

Ícone Android substituído pelo símbolo extraído da imagem fornecida no projeto. Imagem de tela removida da entrada interna. Área Premium em Mais com mensal e 3 meses, seleção acessível, sem preços inventados e cobrança desativada.

Permissão Android do microfone solicitada por plugin nativo registrado; contexto HTTPS local explícito, seleção de MIME compatível e mensagens de erro diferenciadas. Assets públicos incluídos no APK. Versão 1.3.0 / código 13, pacote original preservado.

O código recuperado era o ZIP v12, com pacote com.organizae.app e versionCode 1; não há prova de que corresponda exatamente ao APK instalado nas fotos. Antes de atualizar uma instalação, conferir pacote, versionCode e assinatura do APK atual. Não desinstalar sem exportar os dados.

Voz: o APK anterior usava /api/voice/process no localhost, onde não existe backend. Configuração de origem HTTPS adicionada em Mais > Configurações; nenhum endereço presumido ou chave de API embutida. O Worker fornecido exige oai-authenticated-user-id e origem igual à do servidor. Portanto, apenas preencher URL NÃO basta: ainda é necessário implantar serviço próprio com autenticação independente, CORS restrito à origem Android, limites por usuário, chave OpenAI no servidor e testar envio/transcrição/organização real. Essas proteções existentes não foram removidas. A conexão independente continua pendente.

Validação: 110 testes existentes passaram, TypeScript/build web/sync Android passaram. Testes não comprovam microfone real nem cobrança. APK não compilado: download Gradle bloqueado pela rede; ambiente sem SDK Android configurado. Workflow manual GitHub incluído para compilação; debug APK não substitui assinatura de produção nem comprova compatibilidade de atualização.

Próximas configurações: preço mensal, total de 3 meses, renovação automática ou acesso por prazo; provedor e confirmação de pagamento no servidor antes de ativar Premium. Teste no Xiaomi Android 16 obrigatório.
